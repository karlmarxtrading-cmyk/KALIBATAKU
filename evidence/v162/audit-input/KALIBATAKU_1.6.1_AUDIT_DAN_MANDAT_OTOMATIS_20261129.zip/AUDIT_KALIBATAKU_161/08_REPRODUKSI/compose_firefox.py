import asyncio,json,sys,platform
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(ROOT/'tests/v161'))
import compose_commit as c
from playwright.async_api import async_playwright
async def main():
 out={'engine':'firefox','scope':'Calls unmodified candidate trusted_commits and controlled_order with Firefox only; not physical IME evidence.','checks':[]}
 origin=c.TestOrigin(ROOT/'dist')
 try:
  async with async_playwright() as pw:
   b=await pw.firefox.launch();out['version']=b.version
   for fn in (c.trusted_commits,c.controlled_order):
    ctx=await b.new_context(viewport={'width':390,'height':844})
    try:
     await ctx.add_init_script(c.TRACE)
     p=await ctx.new_page();await c.begin(p,origin.url);await fn(p,out['checks'],'firefox')
    except Exception as e:out['checks'].append({'id':fn.__name__,'status':'FAIL','error':str(e)})
    finally:await ctx.close()
   await b.close()
 finally:origin.close()
 out['failures']=[x for x in out['checks'] if x['status']!='PASS'];out['status']='FAIL' if out['failures'] else 'PASS'
 (BASE/'compose-firefox.json').write_text(json.dumps(out,indent=2))
 print(out['status'],len(out['checks']),out['failures'])
asyncio.run(main())
