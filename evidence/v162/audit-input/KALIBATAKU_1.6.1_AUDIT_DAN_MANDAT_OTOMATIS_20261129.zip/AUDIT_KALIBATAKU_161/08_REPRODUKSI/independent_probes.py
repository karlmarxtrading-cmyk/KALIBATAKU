import json,sys,time,traceback
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
BASE=Path(__file__).resolve().parent
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else BASE/'work'
sys.path.insert(0,str(ROOT/'tests/journey'))
from offline_origin import TestOrigin
origin=TestOrigin(ROOT/'dist')
out={'engine':'firefox','cases':[],'observations':[],'errors':[],'note':'Real browser keyboard automation; synthetic local profiles. No physical mobile keyboard or AT speech.'}

def st(p):
 return p.evaluate('''async()=>{const s=await import('./data/store.js'),scope=s.activeScope();const a=(await s.listAttempts(scope)).find(a=>a.status==='ongoing');if(!a)return null;const e=await s.listEvents(a.attempt_id,scope);return {id:a.attempt_id,index:a.index,count:a.items.length,key:a.items[a.index].question.answer,draft:a.items[a.index].draft,feedback:a.items[a.index].feedback,history:a.items[a.index].history,answers:e.filter(e=>e.event_type==='answer.submitted').length}}''')
def capture(p,name):
 # Screenshots are internal-only; JSON geometry is sufficient for this audit.
 def geo(sel):
  e=p.locator(sel).first
  return e.bounding_box() if e.count() else None
 out['observations'].append({'name':name,'url':p.url,'viewport':p.viewport_size,'scroll_y':p.evaluate('scrollY'),'overflow':p.evaluate('document.documentElement.scrollWidth>innerWidth'),'focus':p.evaluate('document.activeElement.outerHTML.slice(0,350)'),'question':geo('#kp-expression'),'answer':geo('#kp-answer'),'next':geo('[data-part=next]'),'key':geo('.verdict-tile.key'),'feedback':geo('[data-answer-feedback]'),'cta':geo('[data-cta=adventure]'),'text':p.locator('main').inner_text()})

with sync_playwright() as pw:
 b=pw.firefox.launch();out['version']=b.version
 def fresh(w=390,h=844):
  ctx=b.new_context(viewport={'width':w,'height':h},reduced_motion='reduce')
  p=ctx.new_page();p.set_default_timeout(10000)
  p.on('pageerror',lambda e:out['errors'].append(str(e)))
  p.goto(origin.url);p.locator('[data-cta=adventure]').wait_for();return ctx,p
 def enter_start(p):
  p.locator('[data-cta=adventure]').click();expect(p.locator('#kp-answer')).to_be_focused()
 def case(name,fn):
  try:
   result=fn();out['cases'].append({'case':name,'status':'PASS','result':result});print('PASS',name,flush=True)
  except Exception as e:
   out['cases'].append({'case':name,'status':'FAIL','error':str(e),'traceback':traceback.format_exc()});print('FAIL',name,str(e),flush=True)

 def numpad():
  c,p=fresh();enter_start(p);p.locator('#kp-answer').fill('999');p.keyboard.down('NumpadEnter');expect(p.locator('[data-answer-feedback]')).to_be_focused();q=st(p);assert q['index']==0 and q['answers']==1
  p.keyboard.down('NumpadEnter');assert st(p)['index']==0;p.keyboard.up('NumpadEnter');p.keyboard.press('NumpadEnter');expect(p.locator('#kp-answer')).to_be_focused();q=st(p);assert q['index']==1 and q['answers']==1;c.close();return q
 case('Numpad Enter hold and distinct next press',numpad)

 for chord in ['Shift+Enter','Control+Enter','Alt+Enter','Meta+Enter']:
  def modifiers(chord=chord):
   c,p=fresh();enter_start(p);p.locator('#kp-answer').fill('999');p.keyboard.press(chord);p.wait_for_timeout(300);q=st(p);assert q['answers']==0 and q['index']==0 and not q['feedback'];c.close();return {'chord':chord,'stored':q}
  case('Modifier stays unsubmitted '+chord,modifiers)

 def secondary_hold():
  c,p=fresh();enter_start(p);p.locator('#kp-answer').fill('999');p.keyboard.press('Enter');expect(p.locator('[data-answer-feedback]')).to_be_focused()
  p.locator('[data-part=revise]').focus();p.keyboard.down('Enter');expect(p.locator('#kp-answer')).to_be_focused();p.keyboard.down('Enter');p.keyboard.up('Enter');q=st(p);assert q['answers']==1 and q['index']==0;p.locator('#kp-answer').fill('8');p.keyboard.press('Enter');expect(p.locator('[data-answer-feedback]')).to_be_focused();q=st(p);assert q['answers']==2 and q['history'][1]['key_seen_before'];c.close();return q
 case('Held secondary Revise Enter does not submit new input',secondary_hold)

 def no_auto():
  c,p=fresh();enter_start(p);p.locator('#kp-answer').fill('999');p.keyboard.press('Enter');expect(p.locator('[data-answer-feedback]')).to_be_focused();p.wait_for_timeout(1600);q=st(p);assert q['index']==0 and q['answers']==1
  p.locator('.verdict-steps summary').focus();p.keyboard.press('Enter');expect(p.locator('.verdict-steps')).to_have_attribute('open','');assert st(p)['index']==0
  p.keyboard.press('Enter');assert not p.locator('.verdict-steps').evaluate('e=>e.open');assert st(p)['index']==0;c.close();return q
 case('No timed next and native detail toggle',no_auto)

 def blur_hold():
  c,p=fresh();enter_start(p);p.locator('#kp-answer').fill('999');p.keyboard.down('Enter');expect(p.locator('[data-answer-feedback]')).to_be_focused();tab=c.new_page();tab.goto('about:blank');tab.bring_to_front();p.bring_to_front();p.keyboard.down('Enter');q=st(p);assert q['index']==0;p.keyboard.up('Enter');p.keyboard.press('Enter');expect(p.locator('#kp-answer')).to_be_focused();q=st(p);assert q['index']==1 and q['answers']==1;c.close();return q
 case('Held Enter across tab switch stays single then next press works',blur_hold)

 for w,h in [(320,568),(390,844),(844,390),(768,1024),(1440,900)]:
  def layout(w=w,h=h):
   c,p=fresh(w,h);capture(p,f'home-{w}x{h}');enter_start(p);capture(p,f'question-{w}x{h}');p.locator('#kp-answer').fill('999');p.keyboard.press('Enter');expect(p.locator('[data-answer-feedback]')).to_be_focused();capture(p,f'feedback-{w}x{h}');assert not p.evaluate('document.documentElement.scrollWidth>innerWidth');p.goto(origin.url+'#/map');p.locator('.map-node[aria-current=step]').wait_for();capture(p,f'map-{w}x{h}');p.goto(origin.url+'#/packs?grade=1&level=1&op=ADD');p.locator('.pack-filters summary').wait_for();capture(p,f'catalog-{w}x{h}');assert not p.evaluate('document.documentElement.scrollWidth>innerWidth');c.close();return {'viewport':[w,h]}
  case(f'Five views at {w}x{h}',layout)
 b.close()
origin.close();(BASE/'independent-probes.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'cases':len(out['cases']),'failures':[x['case'] for x in out['cases'] if x['status']!='PASS'],'observations':len(out['observations']),'pageerrors':out['errors']}))
