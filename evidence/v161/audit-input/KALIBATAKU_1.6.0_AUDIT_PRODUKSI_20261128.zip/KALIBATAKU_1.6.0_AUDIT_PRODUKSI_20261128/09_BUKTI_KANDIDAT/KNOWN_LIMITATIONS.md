# Batas penerimaan KALIBATAKU 1.6.0

Rilis dikirim untuk validasi terkontrol. Sebelas kriteria wajib memerlukan hasil dari sekolah, perangkat atau domain tujuan. Paket tugas, formulir dan tata cara penyerahan tersedia di VALIDASI_EKSTERNAL/00_MULAI_DI_SINI.md. Pengukuran p75 lapangan dijadwalkan setelah pilot dan deployment yang sesuai.

Profil siswa memakai penyimpanan browser per origin. Siswa yang berganti perangkat atau browser perlu melakukan cadangan dan pemulihan. Pemulihan dan perhitungan kesiapan menggunakan bukti yang tersedia di arsip. Pada riwayat lama, item tanpa bukti bahwa soal pernah dibuka tidak menambah cakupan.

Hasil pengujian desktop, tiga mesin browser, pembacaan berkas ekspor dan preview lokal tercantum di STATUS_RILIS.md. Identitas serta batas bukti masing-masing kriteria tersedia di REGISTER_AC_FINAL.csv.

Uji Windows native tercatat tersendiri pada REGISTER_PENERIMAAN.csv. Verifikasi kedua mesin memakai workflow manual verify-native. Pilot sekolah juga menilai keterjangkauan tindakan dengan keyboard ponsel, penafsiran jejak lokal, frekuensi review dan label tingkat kesulitan.
