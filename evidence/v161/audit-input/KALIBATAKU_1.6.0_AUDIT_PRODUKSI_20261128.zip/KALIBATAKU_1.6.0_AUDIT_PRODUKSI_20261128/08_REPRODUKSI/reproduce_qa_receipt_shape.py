"""Reproduce receipt-shape acceptance without modifying the audited application.

Usage: python reproduce_qa_receipt_shape.py /path/to/extracted/KALIBATAKU [output.json]
The fixture is synthetic QA data, not a real application test or human attestation.
"""
import json, sys, tempfile
from pathlib import Path

sys.dont_write_bytecode = True
source = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(source / 'tools'))
import qa_core

FIXTURE = '''import json,os
from pathlib import Path
out=Path(os.environ['KALIBATAKU_RECEIPTS'])/'malformed.json'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({"schema":"kalibataku-qa-receipt/1","suite":"malformed","build":{"offline_release":"abcdefabcdef0123"},"status":"PASS","assertions":2,"errors":[],"checks":["not an assertion",None]}))
'''

with tempfile.TemporaryDirectory(prefix='kalibataku-audit-receipt-shape-') as td:
    root = Path(td)
    (root/'dist').mkdir()
    (root/'dist/offline-assets.json').write_text(json.dumps({'release':'abcdefabcdef0123','assets':[]}))
    (root/'dist/build-info.json').write_text(json.dumps({'app_version':'audit-synthetic','bank_version':'audit-synthetic'}))
    (root/'dist/index.html').write_text('<!doctype html><title>QA fixture</title>')
    (root/'fixture.py').write_text(FIXTURE)
    spec={'id':'malformed','command':['{python}','fixture.py'],'receipts':['evidence/v13/receipts/malformed.json'],'min_assertions':2}
    registry={'suites':[spec]}
    regpath=root/'registry.json';regpath.write_text(json.dumps(registry))
    ident=qa_core.identity(root);rt=qa_core.runtime()
    out=root/'qa'
    result=qa_core.run_suite(spec,root,out,ident)
    binding=qa_core.write_binding(out,registry,[result],ident,rt,qa_core.sha256_file(regpath))
    problems=qa_core.verify_binding(root,out,regpath,check_runtime=False)
    response={'fixture':'Synthetic malformed receipt; no application or human result claimed','expected':'FAIL: both checks are not assertion objects','actual_suite':result,'actual_binding_status':binding['status'],'verify_binding_problems':problems}
    text=json.dumps(response,indent=2)+'\n'
    if len(sys.argv)>2:Path(sys.argv[2]).write_text(text)
    print(text)
    if result['status']!='PASS' or binding['status']!='PASS' or problems:
        raise SystemExit('Counterexample did not reproduce; inspect output for changed behavior.')
