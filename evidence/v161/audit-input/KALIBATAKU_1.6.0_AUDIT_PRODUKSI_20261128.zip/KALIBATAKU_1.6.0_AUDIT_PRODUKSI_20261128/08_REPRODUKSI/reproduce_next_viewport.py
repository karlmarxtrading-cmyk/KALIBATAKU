"""Read-only browser reproduction; requires extracted candidate and Playwright Firefox."""
import argparse, json, sys
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
root=args.source.resolve();sys.path.insert(0,str(root/'tests/journey'))
from offline_origin import TestOrigin
origin=TestOrigin(root/'dist');results=[]
with sync_playwright() as pw:
    browser=pw.firefox.launch()
    for width,height in [(320,568),(390,844)]:
        context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
        page=context.new_page();page.goto(origin.url);page.locator('[data-cta=adventure]').click();expect(page.locator('#kp-answer')).to_be_focused()
        states=[]
        def capture(label):
            result=page.evaluate('''label=>{const rect=selector=>{const e=document.querySelector(selector);if(!e)return null;const r=e.getBoundingClientRect();return {top:r.top,bottom:r.bottom,height:r.height,fully_visible:r.top>=0&&r.bottom<=innerHeight,intersects_viewport:r.bottom>0&&r.top<innerHeight};};return {label,scroll_y:scrollY,viewport:[innerWidth,innerHeight],position:document.querySelector('#kp-question-position')?.textContent,expression:document.querySelector('#kp-expression')?.textContent,expression_rect:rect('#kp-expression'),input_rect:rect('#kp-answer'),next_rect:rect('[data-part=next]'),focused:document.activeElement?.id||document.activeElement?.tagName};}''',label)
            states.append(result)
        capture('initial')
        page.locator('#kp-answer').fill('999');page.keyboard.down('Enter');page.keyboard.up('Enter');expect(page.locator('[data-answer-feedback]')).to_be_focused();capture('feedback')
        page.keyboard.down('Enter');page.keyboard.up('Enter');expect(page.locator('#kp-answer')).to_be_focused();expect(page.locator('#kp-question-position')).to_contain_text('2 dari');capture('next_question')
        results.append({'engine':'firefox','browser_version':browser.version,'viewport':[width,height],'fresh_profile':True,'input':'999','advance':'new Enter down/up','states':states,'issue_reproduced':not states[-1]['expression_rect']['intersects_viewport']})
        context.close()
    browser.close()
origin.close();args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
