# Perubahan pada KALIBATAKU 1.1.0

## Jawaban siswa dan hasil sesi

Pada 1.0.0, mengetik 5 dan 4 pada dua soal pertama paket G1 L1 ADD P001 bisa menghasilkan dua isian kosong. Kini konfirmasi dan finalisasi memakai keputusan yang sama untuk setiap isian. Draf numerik sah dikomit bersama peristiwa jawabannya. Isian yang masih perlu diperbaiki membuka pilihan yang eksplisit. Jika tenggat berakhir pada revisi yang belum sah, sesi mempertahankan jawaban terakhir yang sah dan menyimpan teks revisi dalam snapshot. Respons pertama tetap tersedia untuk guru meski siswa memperbaiki jawabannya.

Enter mengikuti aksi utama. Evaluasi menyediakan peta nomor soal dan tanda tinjau, termasuk navigasi langsung sebelum pengiriman. Hasil memisahkan skor paket dari akurasi jawaban. Riwayat dapat diakses dari navigasi siswa, dengan ringkasan, filter tanggal/materi/status, dan akses kembali ke sesi terkait. Setiap butir pada tinjauan dapat dipakai untuk meminta soal sejenis dengan fingerprint berbeda. Rekomendasi pada Progres muncul sebelum daftar kemampuan.

## Memulai dan melanjutkan latihan

Beranda menawarkan satu tindakan utama sesuai sesi pada profil aktif. Siswa dapat melihat materi, jumlah dan alasan saran sebelum memulai. Setup menggunakan paket, jumlah soal dan batas waktu dari rencana yang juga dipakai untuk membuat sesi. Evaluasi mengikuti ukuran form aktual dan perbaikan kesalahan mengikuti kesalahan sebelumnya. Unduhan paket menjalani verifikasi byte dan SHA-256 terhadap manifest sebelum dipakai.

Preferensi materi mengikuti pemilik profil pada perangkat bersama. Nama profil terlihat di alur belajar. Tautan riwayat, laporan dan ruang guru memperpendek pencarian menu. Tampilan mendukung bahasa Indonesia dan Inggris, tema sistem, terang dan gelap, teks besar serta pengurangan gerak.

## Guru, orang tua dan operator

Target penugasan diteruskan dari detail siswa. Reset filter mempertahankan sumber dan siswa yang sedang dilihat. Draf catatan, filter, penugasan dan pilihan batch memiliki konteks tersendiri. Catatan baru dapat menggantikan versi sebelumnya dengan jejak revisi. Guru dapat menelaah respons pertama, percobaan ulang dan bantuan yang dipakai.

Ringkasan keluarga memberikan dasar pengamatan dan langkah latihan berikutnya. Pratinjau HTML dan ekspor mengambil snapshot yang sama. Asal data, identitas siswa, periode dan bahasa ikut dalam laporan. PDF, DOCX, XLSX, CSV, JSON dan ZIP dapat dibuat secara lokal. Bukti render dan pembacaan independen ditempatkan di `evidence/teacher/`.

## Penyimpanan dan offline

Ringkasan riwayat memiliki indeks per profil. Detail setiap soal dibaca ketika diperlukan. Pada pemulihan, aplikasi menampilkan pemilik asal, jumlah, rentang tanggal serta rekaman duplikat atau bertentangan. Perubahan target dan konfirmasi penghapusan mengacu pada identitas dan cakupan yang tampak. Berkas pemulihan sesi mendampingi cadangan terverifikasi agar draf tetap terhubung ke ledger aslinya.

Panel offline menghitung ukuran paket beserta dependensi. Status latihan, laporan dan fungsi sekolah terlihat terpisah. Panel pengiriman menampilkan status lokal, antrean, tanda terima dan sumbernya. Data simulasi di perangkat tetap berlabel simulasi.

## Bank soal dan kompatibilitas

Konten bank memakai versi 1.1.0 dan jalur immutable `bank/v1.1/`. Seluruh 177.640 penempatan dicocokkan berurutan terhadap baseline. ID, fingerprint, template, ekspresi, representasi dan kunci eksaknya cocok. Ada 36.274 penempatan dengan petunjuk dan pembahasan ID/EN yang diperbarui.

Contohnya, untuk **98 − 89**, siswa menghitung jarak 89 ke 90 dan 90 ke 98. Untuk **50 × 5**, siswa dapat mengambil setengah dari 500. Kelima contoh audit beserta teks sebelum dan sesudah dapat dibaca di [revisi pedagogis](evidence/ux/bank/named-revisions.json).

Attempt dari 1.0.0 memakai snapshot, versi soal dan ledger miliknya saat dipulihkan. Pengujian memulihkan ekspor asli ke versi baru, melanjutkan draf, memeriksa respons pertama dan melakukan ekspor ulang. [Bukti pemulihan](evidence/ux/upgrade/original-backup-roundtrip.json)

## Bukti yang berlaku

`ACCEPTANCE_RESULTS.csv` dan `AUDIT_CLOSURE.csv` memuat status rilis ini. Bukti rilis 1.0.0 diarsipkan terpisah untuk pembanding. Hasil build/factory diperiksa dengan hash seluruh pohon, dan identitas ZIP asli dicatat di [tanda terima input](evidence/input/source-receipt.json).
