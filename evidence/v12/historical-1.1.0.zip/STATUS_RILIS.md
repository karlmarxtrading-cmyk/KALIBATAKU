# Status rilis KALIBATAKU 1.1.0

**HOLD untuk penerimaan produksi penuh**

Pengujian A5 mencatat 63 PASS, 0 FAIL, 11 BLOCKED dan 6 NOT_RUN dari 80 kriteria. Register melacak 47 temuan.

| Lingkup | Status | Hasil |
|---|---|---|
| static_application | FAIL | 63 dari 73 kriteria WAJIB_STATIC lulus. Keputusan produksi penuh mengikuti seluruh gate wajib. |
| bank_content | PASS | 4.604 paket, 177.640 penempatan, 168.142 ekspresi unik dan 562 form. Kunci serta langkah diperiksa dengan aritmetika eksak. |
| bridge_contract | PASS | Kontrak event, kegagalan, retry dan ACK diuji memakai fixture. Hasil siswa di perangkat tetap berlabel sesuai asal. |
| live_lms | DEFERRED_BY_SCOPE | Integrasi sekolah memerlukan endpoint institusi, akun uji dengan peran berbeda, serta penilai pada server. |
| pedagogical_calibration | NOT_PERFORMED | Tersedia 1.186 sampel dari 394 keluarga template dan 281 kompetensi untuk pendidik dan penelaah bahasa. Kalibrasi dengan siswa belum dijalankan. |
| live_deployment | PREVIEW_PASS | Pratinjau HTTP/HTTPS pada root dan subfolder berhasil. Publikasi GitHub dan domain produksi memerlukan langkah operator. |

## Kriteria wajib yang masih terbuka

| ID | Status | Pekerjaan yang tersisa |
|---|---|---|
| AC-030 | BLOCKED | Keypad matematika mempertahankan caret dan konteks. Pergantian antara keyboard fisik/IME, sentuhan dan seleksi caret pada perangkat sentuh nyata memerlukan perangkat. |
| AC-045 | BLOCKED | Laporan dapat diakses tanpa bergantung PDF visual. Pengucapan aktual, urutan baca dan navigasi pada pembaca layar belum diuji. |
| AC-050 | NOT_RUN | Kontras dan status tidak bergantung warna. Belum ada inspeksi visual lengkap seluruh hover/disabled serta tangkapan fokus dan galat pada mode kontras tinggi; pemeriksaan ini sebagian. |
| AC-053 | BLOCKED | Ukuran sasaran sentuh dan jarak kontrol. Sentuhan jari di Android/iOS, safe-area dan pengecualian di perangkat sasaran belum diuji. |
| AC-055 | BLOCKED | Keyboard virtual Android fisik. Uji IME bawaan, tinggi visual viewport dan ketukan pada ponsel nyata. |
| AC-056 | BLOCKED | Keyboard virtual dan unduhan iOS/iPadOS fisik. Uji keyboard, safe-area, caret dan unduhan Safari iOS/iPadOS pada perangkat. |
| AC-057 | BLOCKED | IME composition tidak memicu submit sebelum selesai. IME fisik bahasa sasaran dan urutan event asli belum diuji. |
| AC-058 | BLOCKED | Pembaca layar aktual mengucapkan matematika dan feedback. Belum ada sesi NVDA/JAWS/VoiceOver/TalkBack dengan pendengar. |
| AC-059 | BLOCKED | Lintas mesin browser dan fallback kompatibilitas. Belum ada Firefox, Safari/WebKit, atau perangkat untuk matriks lintas mesin. |
| AC-080 | BLOCKED | Keputusan rilis, deploy dan bukti terikat build yang sama. Seluruh WAJIB_STATIC dan uji eksternal yang relevan belum PASS. Deployment publik belum dilakukan. |

Buka [bukti pengujian](evidence/00_HASIL_UJI.html) untuk membaca tiap kriteria dan menelusuri berkas pendukung.

SHA-256 pohon distribusi publik: `259d9993a4a8de9d3c08c48228ad7be91402d7576c0050faa22a4f81ff3cf058`.
