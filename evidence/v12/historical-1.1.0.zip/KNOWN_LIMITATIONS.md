# Kesiapan produksi dan pengujian yang masih diperlukan

**Artefak statis tersedia untuk dipasang.** Keputusan penerimaan produksi mengikuti [matriks aktual](ACCEPTANCE_RESULTS.csv) dan [status per bidang](STATUS_RILIS.md). Tiap baris yang belum lulus mencantumkan hasil yang sudah diamati dan bagian yang masih perlu diuji. Data dalam laporan contoh berasal dari profil sintetis.

| Cakupan | Cara menutupnya |
|---|---|
| Penggunaan di Android dan iOS | Jalankan alur soal dengan keyboard sistem pada ponsel fisik dalam potret dan lanskap. Ketik pecahan, angka negatif dan desimal. Gunakan komposisi, koreksi, Enter dan buka/tutup keyboard. Catat versi OS, browser, perangkat, posisi tombol utama, jumlah event dan hasil final. Catat pergantian keypad dan keyboard serta ukuran target sentuh aktual dalam AC-030, AC-053, AC-055, AC-056 dan AC-057. |
| Pembaca layar dan lintas browser | Tempuh alur mulai, jawab, tinjau, batalkan, kirim, serta baca hasil dengan TalkBack/VoiceOver dan NVDA. Catat ucapan matematika dan perubahan fokus. Jalankan ulang pada Safari/WebKit dan Firefox nyata, termasuk commit transaksi, unduhan serta fallback. Gunakan AC-058–059. |
| Kontras tinggi dan fokus | Bandingkan layar dengan kontras tinggi sistem dan tampilan monokrom. Periksa teks status, garis tepi, fokus, dan legenda di atas latar aktual sesuai AC-050. Rasio yang sudah diukur per tema tersedia di `evidence/ux/shell/localization-coverage.json`. |
| Kemudahan untuk pengguna nyata | Ikuti tugas AC-076–079 untuk siswa, guru, operator dan orang tua. Catat jumlah yang berhasil tanpa arahan, waktu, kesalahan, bantuan dan pemahaman asal data. Gunakan rencana dan rubrik yang disertakan dalam [rencana penerimaan](evidence/input/05_KRITERIA_PENERIMAAN_DAN_UJI.md). |
| Kualitas penjelasan dan tingkat kesulitan | Pendidik dan penelaah bahasa memeriksa [roster 1.186 sampel](evidence/ux/bank/editorial-roster.csv), mendokumentasikan komentar, keputusan, identitas reviewer serta uji ulang. Ukur kesulitan empiris dan kesetaraan A/B pada kelompok siswa sesungguhnya sebelum mengklaim kalibrasi. |
| LMS sekolah | Operator sekolah menyediakan endpoint staging, akun beberapa peran dan kelas, serta lingkungan penilaian server. Uji batas akses antar-kelas, retry, ACK, perbedaan penerimaan dan validasi nilai pada AC-067. |
| Deployment publik dan kinerja lapangan | Setelah operator memublikasikan `dist/`, rekam URL dan deployment ID, lalu periksa deep link, 404, MIME, cache, install offline dan ekspor profil. Gunakan pengukuran dari pengguna nyata untuk melaporkan p75 LCP, INP dan CLS menurut perangkat serta periode trafik pada AC-070. |

## Penyimpanan dan laporan di sekolah

Riwayat pribadi berada pada browser dan origin tempat latihan. Siswa pada komputer bersama perlu memastikan alias aktif dan menyimpan cadangan untuk pindah perangkat. Akses ke folder data browser memungkinkan akses sesuai izin perangkat. Simulasi guru menggunakan identitas demo lokal. LMS produksi memerlukan identitas dan kontrol akses yang dikelola sekolah.

Laporan keluarga dapat dibaca sebagai HTML semantik. Sampel PDF telah diperiksa menggunakan perender dan pembaca teks. Ekspor PDF saat ini belum menyediakan struktur tagged PDF yang terverifikasi. Untuk karakter yang belum didukung font PDF, gunakan pratinjau HTML atau format lain yang ditawarkan aplikasi.
