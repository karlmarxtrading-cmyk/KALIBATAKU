# A5 — Kriteria penerimaan dan rencana pengujian

**Tanggal:** 26 November 2026 · **Objek berikutnya:** build website hasil perbaikan UI/UX.  
**Daftar rinci:** `KRITERIA_PENERIMAAN.csv`, berisi **80 kriteria AC-001–AC-080**. Semua status awal untuk build perbaikan adalah **NOT_RUN**. Dokumen ini menetapkan pekerjaan dan bukti yang dibutuhkan; tidak menyatakan website baru sudah dibuat atau diuji.

## 1. Cara menentukan bahwa pekerjaan selesai

Selesai berarti tugas pengguna dapat dituntaskan dengan benar, pekerjaan tersimpan, dan konteks siswa maupun sumber data tetap tepat. Penampilan yang lebih rapi harus menghasilkan perilaku yang lebih mudah dipahami. Setiap kriteria perlu dihubungkan dengan implementasi, build yang diuji, hasil aktual, dan bukti. Foto layar saja tidak cukup untuk membuktikan penyimpanan atau finalisasi yang benar.

CSV menyediakan prasyarat, langkah, hasil yang diharapkan, metode, prioritas, bukti wajib, dan jenis gate. Pelaksana mengisi kolom `build_yang_diuji`, `hasil_aktual`, `path_bukti`, `tanggal_uji`, dan `pelaksana`. Pertahankan observasi baseline agar alasan perbaikan tetap dapat ditelusuri. Simpan hasil sebagai salinan baru yang terikat pada hash build; jangan mengubah temuan lama menjadi seolah-olah sejak awal lulus.

Kolom `prioritas` menentukan **urutan dan urgensi pengujian**, bukan menghitung jumlah bug atau mengubah tingkat keparahan temuan bagian B. AC-004 dan AC-005 memakai P1 agar konsisten dengan temuan konteks guru/laporan; keduanya tetap gate wajib. Satu temuan dapat membutuhkan beberapa kriteria, dan satu kriteria dapat memeriksa beberapa risiko yang berkaitan.

Gunakan status PASS, FAIL, NOT_RUN, atau BLOCKED beserta alasan. PASS memerlukan bukti hasil aktual; dokumen rancangan, tombol yang terlihat, dan perintah yang selesai tanpa error belum otomatis membuktikan seluruh kriterianya. Bila satu kasus memiliki beberapa varian wajib, semua varian harus dicatat. Varian yang belum dijalankan tidak boleh hilang dari laporan.

## 2. Regresi yang harus ditutup terlebih dahulu

Audit langsung menemukan empat masalah yang menyentuh kepercayaan pengguna. Jadikan reproduksinya tes regresi tetap sebelum mengganti komponen visual.

| Kasus | Perilaku asli yang teramati | Hasil yang wajib dicapai |
|---|---|---|
| **AC-001–003: jawaban dan finalisasi** | Practice, G1 L1 ADD P001, dua soal: isi 5 untuk `0+5`, tekan Lanjut, isi 4 untuk `0+4`, lalu selesaikan. Konfirmasi menyebut 0 kosong, tetapi hasil mencatat 2 kosong. Pemeriksaan mesin juga menemukan revisi belum diperiksa dapat kembali ke respons lama. | Setiap draf sah dipertahankan dan dikomit melalui tindakan yang jelas. Dua respons benar yang telah dikomit menghasilkan 2/2 benar dan 0 kosong. Konfirmasi dan hasil memakai definisi status yang sama. |
| **AC-004: sasaran tugas** | Dari detail Demo 04, Buat penugasan membuka sasaran Demo 01. | Nama dan identitas siswa terbawa sampai tugas disimpan; perubahan sasaran hanya melalui pilihan eksplisit. |
| **AC-005: sumber laporan** | Reset filter laporan personal kembali ke sumber demo. | Reset mempertahankan sumber dan siswa aktif; pratinjau dan berkas unduhan tetap berasal dari konteks yang dipilih. |
| **AC-006: draf catatan** | Catatan guru yang belum disimpan menjadi kosong setelah ID→EN. | Isi, sasaran, jenis catatan dan status belum disimpan bertahan; perubahan bahasa mengganti penyajian tanpa membuang pekerjaan. |

Untuk jawaban, perluas regresi ke Practice, Assessment, Speed, Adaptive, dan Recovery; respons pertama salah lalu direvisi; draf invalid; kedaluwarsa waktu; pause; reload; penyimpanan gagal; serta ketukan ganda. Penghapusan tombol Lanjut lama merupakan pilihan implementasi yang sah, tetapi semua rute programatik tetap harus mencegah kehilangan draf. Bukti meliputi rekaman alur, ledger/event, snapshot final, ID paket, versi konten, dan hash build. [S1]

AC-008 juga memeriksa penolakan penyimpanan sejak awal: sebelum sesi dimulai, pengguna harus memahami bahwa mode sementara dapat kehilangan data saat browser ditutup dan memilih kelanjutannya. AC-060 memeriksa cakupan offline per fitur; latihan yang siap offline tidak boleh membuat monitoring guru atau ekspor laporan yang belum tersimpan terlihat siap. Batas tersebut harus jelas sambil menjaga latihan yang sudah tersedia tetap berfungsi.

## 3. Peta 80 kriteria

| Kriteria | Fokus |
|---|---|
| AC-001–008 | Regresi data, konteks siswa, draf, ketukan ganda dan gagal simpan |
| AC-009–018 | Navigasi, profil, beranda, mulai cepat, kurikulum, katalog, setup, deep link |
| AC-019–030 | Tindakan player, parser, lima mode, peta evaluasi, pause, konflik tab, locale dan keypad |
| AC-031–035 | Hasil, review, riwayat, mastery, rekomendasi |
| AC-036–045 | Monitoring, detail siswa, tugas, revisi catatan, laporan dan enam format ekspor |
| AC-046–051 | ID/EN, draf guru, format angka, tema sistem/terang/gelap, kontras, reduced motion |
| AC-052–059 | Layout, sentuh, keyboard, Android/iOS fisik, IME, pembaca layar, lintas browser |
| AC-060–067 | Offline, cache, versi, pemulihan, bridge dan gate LMS nyata |
| AC-068–071 | Budget byte, respons interaksi, lab/field performance, data besar |
| AC-072–075 | Cakupan bank, kebenaran matematis, kurasi pembahasan, form evaluasi/pool |
| AC-076–079 | Tugas siswa, guru, admin dan pemahaman orang tua |
| AC-080 | Bukti rilis, distribusi, status kesiapan dan batas klaim |

`requirement_id` R-01 sampai R-15 merujuk nomor bagian A1: hasil, landasan, peran, navigasi, beranda, setup, player, evaluasi, hasil belajar, guru/laporan, bilingual, perangkat/tema, kinerja, data/bridge, dan urutan pelaksanaan. **Rancangan baru A2 memiliki 20 layar logis L01–L20; seluruhnya menjadi sasaran pengujian.** Kolom CSV `layar_rancangan` memuat ID baru tersebut. Kolom `layar` mempertahankan UX-01–UX-18 sebagai keterlacakan historis ke 18 layar spesifikasi sumber, bukan menyatakan rancangan baru hanya mempunyai 18 layar. Satu layar sumber dapat dipisah menjadi beberapa layar baru, atau digabung, tanpa menghilangkan pekerjaan maupun state. [S2]

## 4. Matriks antarmuka yang wajib terlihat dalam bukti

Periksa **seluruh 20 layar rancangan L01–L20** pada ID dan EN serta tema terang dan gelap. Untuk setiap layar, sertakan state yang berlaku: kosong, normal, loading, error, berhasil, dan pekerjaan belum tersimpan. Gunakan `layar_rancangan` pada CSV untuk cakupan implementasi baru; ID UX lama tetap tersedia untuk menelusuri sumber. Tema sistem diuji sebagai preferensi tersendiri. Bahasa laporan Indonesia/English/bilingual terpisah dari bahasa antarmuka.

Gunakan matriks ukuran sumber: **320×568, 360×800, 390×844, 568×320, 768×1024, 1024×768, 1366×768, 1440×900, dan lebar 2560 CSS px**. Uji pembesaran teks 200%, reflow pada lebar efektif 320 CSS px, orientasi lanskap, dan safe area. Catat viewport aktual, bukan hanya ukuran yang diminta runner. Jalankan seluruh rute pada ukuran minimum dan desktop; parametrisasikan matriks lengkap pada pola yang berbeda, terutama katalog, player, monitoring, laporan, profil/offline dan pengaturan. Jangan menyamarkan layar yang belum diperiksa sebagai tercakup karena komponen lain lulus. [S2]

Target produk utama/keypad adalah 48×48 CSS px; kontrol lain diutamakan 44×44. Ini pilihan kenyamanan proyek. Ketentuan minimum WCAG 2.2 AA sebesar 24×24 memiliki pengecualian tertentu; jangan mengganti maknanya dengan klaim bahwa 44/48 adalah minimum AA. Periksa kontras pada warna aktual, bukan token saja, dan status dengan penanda selain warna. [S2; R1]

Keyboard-only harus mencakup skip link, tabel, peta soal, disclosure, dialog, return focus, dan fokus setelah lazy load. Untuk IME, Enter saat composition belum selesai harus menyelesaikan pengetikan, bukan mengirim jawaban atau formulir lain. Pengujian Android/iOS harus memakai keyboard sistem nyata; emulasi tinggi viewport tidak menggantikannya. Dengarkan ucapan pembaca layar pada pecahan, bilangan negatif, error, feedback dan progres; accessibility tree tidak membuktikan waktu pengumuman. Simpan nama alat, OS, browser dan versinya. [S2; R2]

## 5. Anggaran kinerja yang dipertahankan

Anggaran berikut diwarisi dari spesifikasi sumber, bukan angka baru untuk melonggarkan standar. Gunakan KiB gzip, catat ukuran mentah serta ukuran transfer hosting jika berbeda, dan hindari menghitung dependensi bersama dua kali. [S2]

| Unit | Batas |
|---|---:|
| JavaScript awal kumulatif | 150 KiB |
| CSS awal | 35 KiB |
| Satu locale | 25 KiB |
| Manifest root | 20 KiB |
| Shard katalog terpilih | 50 KiB |
| Tambahan player | 90 KiB |
| Satu paket soal | 60 KiB |
| Tambahan rute guru/admin, masing-masing | 150 KiB |
| Total font awal | 100 KiB |
| Exporter per format | Ukur dan catat; tidak masuk initial bundle |

Indikator klik/input ditargetkan terlihat dalam **≤100 ms pada profil uji yang dicatat**. Uji cold/warm, kegagalan unduh, pemilihan cepat, submit/next, preview laporan, dan ekspor bersamaan dengan interaksi. Player tidak meminta jaringan untuk setiap soal setelah paket sesi siap. Katalog tidak mengimpor seluruh bank.

Pengukuran lab membutuhkan minimal tiga run per profil, konfigurasi CPU/jaringan/viewport, median dan rentang. LCP ≤2,5 detik dan CLS ≤0,1 menjadi sasaran lab proyek. **INP lapangan bukan angka yang dapat diganti oleh TBT atau Lighthouse.** Target field LCP ≤2,5 detik, INP ≤200 ms, dan CLS ≤0,1 berlaku pada persentil ke-75, dipisahkan mobile/desktop. Jika belum ada data penggunaan, AC-070 tetap NOT_RUN dan ditempatkan sebagai tindak lanjut field, bukan alasan menahan distribusi statis yang sudah memenuhi gate lain. [S2; R3]

## 6. Pengujian bank dan kurasi pembelajaran

Pertahankan baseline 12 kelas, 60 level, 281 kompetensi aktif, 19 slot nonaktif, 4.604 paket dan 177.640 penempatan. Seluruh paket harus nyata dan dapat ditemukan, bukan diganti contoh kecil. Setiap perubahan isi/penjelasan memerlukan versi yang menjaga snapshot lama. Hitung ulang seluruh jawaban dan langkah dengan oracle independen; periksa domain, hasil antara, bentuk MIX, prasyarat, tampilan pecahan/desimal, serta fixture positif/batas/negatif untuk setiap template. [S3]

Untuk kurasi manusia, gunakan **seluruh 394 template yang teramati** sebagai roster awal. Pilih sedikitnya tiga contoh berbeda per template: bentuk tipikal, batas yang relevan, serta kasus dengan beban narasi atau transformasi terbesar. Target awal sekitar **1.182 penempatan review**, yang dapat saling memenuhi cakupan 281 kompetensi; bila satu pool lebih kecil, review seluruh kandidat dan catat pengecualiannya. Jika template baru ditambahkan, tambahkan ke roster. Jangan membatasi review pada satu soal per kelas.

Setiap contoh dibaca berpasangan ID/EN. Reviewer pendidik menilai kesesuaian instruksi, prasyarat strategi, kegunaan hint, jumlah langkah yang tidak perlu, serta kemungkinan penjelasan lebih sederhana. Reviewer bahasa memeriksa kesetaraan makna dan istilah. Catat identitas reviewer nyata, question ID, keputusan, revisi, dan bukti pemeriksaan ulang. Contoh `98−89`, `50×5`, serta pemfaktoran/kompensasi yang berputar perlu masuk sampel. Pemeriksaan otomatis seluruh nilai tetap berjalan sesudah revisi. [S1; S3]

Form A/B pada semua 281 kompetensi diperiksa untuk blueprint dan overlap. Pool kecil serta fingerprint berulang tidak boleh memperbesar bukti independen. Review editorial dan kesetaraan rancangan **belum merupakan** kalibrasi kesukaran empiris atau equating psikometrik; status tersebut tetap terpisah.

## 7. Uji tugas pengguna: target usulan, belum hasil terukur

Mulai pilot formatif setelah regresi P0 ditutup. **Usulan rekrutmen awal adalah lima orang per kelompok**: siswa kelas 1–2, 3–6, 7–9, 10–12, guru, admin/operator, dan orang tua; total sekitar 35 peserta. Ini rencana praktis untuk menemukan masalah, bukan dasar menyatakan seluruh populasi pasti terbantu. Gunakan persetujuan/pendampingan yang sesuai dan data sintetis; nilai latihan pilot bukan catatan akademik resmi.

Sasaran yang diusulkan adalah **≥80% peserta dalam setiap kelompok menyelesaikan setiap tugas kritis tanpa bantuan pengarah**, dengan **nol kehilangan data atau sasaran siswa yang salah**. Pada kelompok lima orang, laporkan bilangan mentah seperti 4/5, bukan persentase saja. Siswa kembali ditargetkan mulai melalui paling banyak dua tindakan utama. Catat waktu, salah klik, langkah yang diulang, permintaan bantuan dan kata yang tidak dipahami; jangan menjadikan waktu uji sebagai tekanan atau nilai kecepatan berhitung anak.

Guru diuji dari menemukan kebutuhan siswa hingga membuat tugas dan laporan. Target waktu penugasan sederhana sekitar dua menit merupakan usulan desain yang harus ditinjau melalui pilot. Admin diuji membedakan lokal/demo/server, membuat cadangan dan memulihkan profil yang tepat. Orang tua membaca ringkasan lalu menyebut **satu kekuatan, satu kebutuhan bantuan, dan satu tindakan berikutnya**; sasaran usulan ≥80% menjawab ketiganya dalam sekitar tiga menit tanpa penjelasan pengembang. Tidak seorang pun boleh salah menganggap simulasi sebagai nilai resmi. Laporkan akomodasi yang dibutuhkan dan kesalahan kritis tersendiri, walaupun rata-rata keberhasilan tinggi.

## 8. Status sekarang dan keputusan rilis berikutnya

Audit paket telah membuktikan pemeriksaan integritas 5.033 file, kecocokan manifest 4.604 paket, serta perhitungan ulang 177.640 kunci dan 356.105 langkah tanpa ketidakcocokan pada lingkup scan tersebut. Paket lama melaporkan 88/90 tes penerimaan PASS, dengan keyboard virtual fisik dan screen reader aktual NOT_RUN, serta keputusan HOLD. Temuan browser baru menunjukkan mengapa PASS teknis tersebut tidak cukup untuk menyatakan seluruh pengalaman pengguna benar. **Semua 80 target build perbaikan tetap NOT_RUN sampai diuji pada build baru.** [S1; S4]

Pisahkan keputusan berikut:

- **GO_STATIC:** semua kriteria `WAJIB_STATIC` lulus; tidak ada P0/P1 terbuka atau P2 yang melanggar kebutuhan wajib pada lingkup yang diklaim. Distribusi, hash, preview dan pemulihan telah diperiksa.
- **Klaim UX maksimal:** selain gate statis, tugas pengguna AC-076–079 dan review terkait sudah memiliki bukti; belum ada peserta berarti belum boleh mengaku telah dibuktikan mudah bagi pengguna nyata.
- **Kualitas pembelajaran:** kurasi AC-074 dilaporkan dengan roster dan reviewer; pilot/equating empiris hanya disebut jika benar-benar dilakukan.
- **LMS live:** AC-067 memerlukan server nyata, autentikasi, otorisasi dan penilaian tepercaya. Untuk rilis statis, lingkup ini tetap DEFERRED; mock ACK tidak menutupnya.
- **Field performance:** AC-070 dilaporkan ketika data lapangan tersedia. **Deployment publik:** membutuhkan URL dan deployment ID serta smoke test pada lingkungan tersebut; preview lulus hanya berarti preview lulus.

Bila alat/perangkat tertentu belum tersedia, selesaikan seluruh pekerjaan lain yang dapat dilakukan dan catat gate yang tersisa secara konkret. Jangan menurunkan status ke PASS, menonaktifkan kontrol, atau menghapus tes agar laporan tampak lengkap. Paket akhir harus memungkinkan reviewer mengulang temuan dan menghubungkan setiap hasil dengan source serta `dist` yang sama.

## Sumber dan keterlacakan

- **S1 — Audit baru:** bagian B, bukti uji langsung, hasil audit player/guru, `package_scan_results.json` dan `pedagogical_examples.json` pada lampiran audit.
- **S2 — Spesifikasi asli:** `spec/01_ARAHAN_UI_UX.md` bagian 5–6, 12–14; `spec/06_ACCEPTANCE_QA_DAN_RILIS.md` bagian 8–12. Semua path sumber merujuk ZIP asli yang diaudit.
- **S3 — Kontrak konten asli:** `spec/05_BANK_SOAL_FACTORY.md`, `spec/planning/mastery_policy.json`, `factory/README.md`, registry efektif dan errata; hasil scan bank audit baru.
- **S4 — Bukti rilis asli:** `STATUS_RILIS.md`, `RELEASE_STATUS.json`, `evidence/acceptance/test-matrix.json`, `evidence/bank/template-review.json`.
- **R1:** [W3C — Target Size (Minimum)](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum).
- **R2:** [W3C — Reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow) dan [Focus Not Obscured (Minimum)](https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum).
- **R3:** [web.dev — Web Vitals](https://web.dev/articles/vitals).
