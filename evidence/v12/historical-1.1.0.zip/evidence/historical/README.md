# Bukti historis

`evidence-1.0.0.zip` berisi salinan byte berkas bukti, inventaris, checksum dan status rilis dari ZIP 1.0.0 sebelum perbaikan. Jalur dan nama dipertahankan agar rujukan historis dapat dikenali. Untuk rilis 1.1.0, mulai dari [indeks hasil uji](../00_HASIL_UJI.html).
