# Bukti alur menjawab

Dalam reproduksi S01, murid mengetik 5 untuk 0 + 5 lalu langsung memilih Lanjut. Pada soal kedua ia mengetik 4 untuk 0 + 4 dan menyelesaikan sesi. Pada 1.0.0, pratinjau menyebut nol kosong. Hasil akhirnya mencatat dua kosong. Pembanding mesin awal tersimpan di `S01-baseline.json` dan rekaman browser awal berada di `../acceptance/browser-baseline-ux.json`.

Pada build baru, Lanjut menyimpan respons pertama. Pratinjau menghitung dampak draf kedua tanpa mengirim event. Kirim hasil menulis respons kedua dan event penyelesaian dalam satu transaksi. Kedua respons final menunjuk event jawaban yang tepat pada ledger. Berkas `finalization.json` mencatat hitungan dan urutan event untuk setiap skenario. Uji browser baru menyimpan input nyata, tampilan, dan hasil di `../acceptance/browser-player-ux.json`.

## Kebijakan selama sesi

| Mode | Tindakan utama | Ketika jeda | Ketika hasil dikirim |
| --- | --- | --- | --- |
| Latihan | Periksa, coba lagi, atau lanjut sesuai keadaan | Nomor dan draf disimpan. Penghitungan waktu aktif dijeda. | Draf sah terakhir dihitung. Respons pertama dan bantuan tetap tercatat. |
| Tantangan waktu | Periksa dan lanjut | Penghitungan waktu aktif dijeda. Tenggat tetap berjalan. | Bila waktu habis, isian sah dihitung. Isian belum lengkap disimpan sebagai catatan dan mempertahankan jawaban atau status terdahulu. |
| Evaluasi | Simpan dan lanjut | Jeda mempertahankan nomor dan tanda tinjau. Tenggat yang sudah ditetapkan tetap berjalan. | Peta soal menampilkan status jawaban sebelum kirim. Hasil benar dan salah terbuka setelah transaksi selesai. |
| Adaptif | Periksa, coba lagi, atau lanjut | Draf dan pilihan materi sesi tersimpan. | Hasil dan riwayat keputusan memakai sesi yang sama. |
| Perbaikan | Periksa soal asal lalu variasinya | Draf dan hubungan dengan soal asal tersimpan. | Latihan baru mempunyai ledger sendiri. Respons pertama pada sesi asal tetap dapat dibaca. |

Untuk penyelesaian manual, draf yang belum lengkap harus diperbaiki atau ditandai kosong secara eksplisit. Soal yang dilewati atau belum pernah dilihat mempunyai status sendiri. Saat perangkat gagal menyimpan, murid dapat mencoba kembali atau mengunduh cadangan profil yang dapat dipulihkan. Berkas salinan sesi mentah berfungsi sebagai catatan baca.

## Menjalankan kembali

Dari akar proyek, `node tests/player/ux-domain.mjs` menjalankan kasus mesin, penyimpanan transaksional sementara Node, validasi cadangan, dan bridge simulasi. `node tests/player/run.mjs` memeriksa parser serta metrik. `node tests/player/ledger.mjs` memeriksa urutan ledger. Uji khusus migrasi dijalankan melalui `node tests/upgrade/restore.mjs`.

Untuk interaksi browser, jalankan `python3 tests/integration/ux_server.py`, buka alamat yang dilayani, lalu pilih suite player. Runner memakai profil sintetis dalam origin uji. `acceptance-map.json` menghubungkan kriteria dengan pemeriksaan dan keterbatasannya. Status akhir terikat build tersedia dalam `ACCEPTANCE_RESULTS.csv` di akar ZIP. Ponsel fisik, IME sistem, pembaca layar dan pemahaman siswa memerlukan pengujian terpisah.
