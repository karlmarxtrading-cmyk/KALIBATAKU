# Uji bahasa, warna dan tema

Build statis `2ae6aa2494074467`. Rincian lokasi sumber, kunci, teks layar, bahasa, tema, dan rasio berada di `localization-coverage.json`.

| Pemeriksaan | Hasil |
| --- | --- |
| Kamus ID dan EN | 197 kunci berpasangan. Sebanyak 185 pemanggilan kamus dipetakan, termasuk operasi, mode, tujuan paket, dan pesan kesalahan. Kunci atau nilai yang hilang 0. Bentuk dinamis yang belum terurai 0. |
| Teks di luar kamus | 660 pemanggilan bilingual dan 91 entri tabel bernama diinventarisasi. 7 literal yang langsung masuk ke kontrol atau teks DOM dicatat satu per satu, dengan klasifikasi nama produk, fallback bersama, atau istilah yang dipakai pada kedua bahasa. |
| Fungsi UI yang dieksekusi | 49 dari 49 kasus menghasilkan keluaran ID dan EN yang terisi. Kasus mencakup validasi angka, penguncian dan kegagalan penyimpanan, konflik catatan, kegagalan materi, mode sesi, status laporan dan asal data. |
| Struktur bank | 4.604 paket dan 177.640 penempatan soal diperiksa. Bidang bilingual wajib yang hilang 0. Penilaian makna dan tingkat baca oleh pendidik mempunyai gate tersendiri pada AC-074. |
| Layar Chromium | 64 keadaan pada kombinasi 16 rute, dua bahasa dan dua tema. 3.196 pengukuran teks. Sebanyak 4 latar yang ambigu dikecualikan. Rasio sampel terendah 5,74∶1 dalam terang dan 7,01∶1 dalam gelap. Pelanggaran kontras teks 0. Kunci yang muncul sebagai heading 0. |
| Nilai JavaScript pada tampilan | 0 pemeriksaan salinan terlihat gagal dari 64 keadaan yang dicoba. Kandidat argumen persis berupa kondisi boolean, null atau undefined pada pemanggilan native DOM dalam sumber 0. |
| Fokus dan status | 38 dari 38 pasangan CSS untuk fokus, tepi kontrol, hover, peringatan dan error lolos ambang per kasus. Ada 18 pasangan tepi/fokus dengan ambang 3∶1 dan rasio terendah 3,69∶1. |
| Tema | 2 kasus preferensi dan perubahan media lulus. Perubahan media sistem disimulasikan dalam Chromium. Jejak awal dan preferensi setelah reload tercatat di `browser-shell-ux.json`. |

Kelima hasil uji browser untuk semantik, tampilan, player, ruang guru, dan preferensi cocok dengan build ini.

Inventaris memisahkan teks langsung, pasangan yang dihitung, serta pesan yang dipilih lewat tabel. Lokasi dan redaksi mencakup kegagalan memuat, kesalahan ekspor, pembatalan, font PDF, dan penyimpanan sementara. Laporan memakai tabel dan angka. Ikon SVG pada shell bersifat dekoratif.

Saat profil pribadi utama belum diberi nama, model laporan memakai alias bawaan Local. Shell menampilkan Profil utama atau Main profile menurut bahasa. Alias pengguna, nama produk, dan ID teknis di lampiran laporan dicatat terpisah dari kunci antarmuka.

Pemeriksaan kontras browser membaca warna efektif pada layar yang dicantumkan. Uji pasangan CSS melengkapinya untuk keadaan fokus, hover, peringatan, dan error. Mode kontras tinggi fisik, seluruh kombinasi pembaca layar, serta penilaian makna pedagogis oleh manusia berada di luar hasil ini.

Untuk mengulang dari akar paket, jalankan `node --expose-internals tests/ui/localization-audit.cjs` pada Node 24. Pengujian memakai Acorn yang disertakan Node.
