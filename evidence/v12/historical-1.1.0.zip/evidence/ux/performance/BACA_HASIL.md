# Pengukuran performa

`performance-summary.json` memuat median, nilai minimum dan maksimum per tindakan. Semua angka berasal dari rilis dan lingkungan yang tercantum pada berkas. `../acceptance/browser-perf-ux.json` menyimpan pengamatan mentah. Bukti byte mentah dan gzip berada di `bundle-gzip.csv`. `module-graph.json` memisahkan impor statis, impor dinamis literal dan dependensi yang direferensikan dengan URL. `export-format-costs.json` menghitung dependensi statis unik setiap format serta font PDF, termasuk biaya yang dibagi beberapa format.

## Kondisi dan cara mengulang

1. Bangun distribusi memakai `npm run build`.
2. Jalankan `python3 tests/integration/ux_server.py --port 4173` di root hasil ekstraksi.
3. Buka `http://127.0.0.1:4173/__qa/perf/lab.html` dalam profil browser uji. Klik **Run performance study**. Jendela anak membuka situs dengan prefiks jalur berbeda pada setiap pengulangan. Tidak ada pembatasan CPU atau jaringan buatan dalam profil ini.
4. Tunggu tanda selesai dan kode 204. Jalankan `python3 tests/perf/analyze.py`. Periksa kecocokan `release` dan `analyzed_dist_release`.
5. Bandingkan hasil antarrilis menggunakan browser, perangkat, ukuran viewport dan konfigurasi jaringan yang sama.

Skenario navigasi memakai lima prefiks baru untuk mengukur tampilan awal beranda. Klik dan input dijalankan oleh kode uji. Observer mengukur perubahan DOM pertama setelah tindakan dan waktu sampai fungsi siap. Di samping waktu perubahan DOM, dua callback animasi berturut-turut mencatat kesempatan browser merender pembaruan. LCP berasal dari PerformanceObserver pada pemuatan beranda. Skenario hangat membuka dokumen baru dengan URL aset yang sama dan mengikuti kebijakan cache browser. CLS beranda dihitung sebagai klaster pergeseran terbesar sebelum berpindah rute. Ukuran gzip lokal dihitung terpisah dari transfer yang tercatat oleh Resource Timing.

Uji beban membuat 1.200 sesi sintetis dalam profil khusus dan 41 sesi kontrol di profil lain. Uji itu melakukan pengisian indeks, penelusuran halaman, filter, perpindahan halaman pada komponen riwayat, perhitungan progres melalui worker, dan pembuatan snapshot laporan. Setiap pengulangan membuat satu ZIP berisi 100 PDF sintetis dan menghentikan batch terpisah setelah tiga pemberitahuan kemajuan. Setiap arsip selesai diperiksa pada direktori pusat ZIP untuk 100 entri PDF dan satu manifes. Uji memeriksa jumlah dan urutan hasil, jumlah elemen yang dirender, penerimaan input selama ekspor, jeda antartimer dan durasi tugas panjang. Data sintetis yang dibuat laboratorium dihapus setelah selesai.

Pembacaan heap menggunakan nilai yang diekspos Chromium. Nilainya dipengaruhi waktu garbage collection dan tidak mencakup semua worker, database dan buffer native. Pengujian lima siklus dapat menemukan pertumbuhan terus-menerus yang tampak pada sampel. Anggaran memori perangkat sekolah memerlukan pengukuran pada perangkat sasaran. AC-070 tetap `NOT_RUN` selama data lapangan belum tersedia.
