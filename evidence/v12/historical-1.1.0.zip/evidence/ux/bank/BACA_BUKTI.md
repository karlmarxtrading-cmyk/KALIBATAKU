# Bank soal 1.1.0

Bank dapat digunakan dari `dist/bank/index.json`. Manifes mengarah ke 4.604 modul mandiri di `dist/bank/v1.1/`. Setiap entri paket mencatat ID, versi, jumlah, judul, ukuran byte sebelum kompresi dan SHA-256. Versi isi dan revisi butir adalah `1.1.0`. Bentuk kontrak data mengikuti schema `1.0.0`; kurikulum efektif memakai `1.0.0-draft.2`.

| Bukti | Pertanyaan yang dijawab |
|---|---|
| `release-comparison.json` | Apakah seluruh posisi dari bank asli memuat ekspresi, identitas, representasi dan jawaban yang sama? Berapa petunjuk, pembahasan dan langkah yang direvisi? |
| `named-revisions.json` | Bagaimana lima contoh audit ditampilkan dalam kedua bahasa, termasuk operasi antara? |
| `assessment-pairs.json` | Berapa banyak fingerprint yang sama dan berbeda pada kedua form setiap kompetensi? Apakah strata rancangan sepadan? |
| `snapshot-upgrade.json` | Apakah draf 1.0.0 dapat dipulihkan, dinilai, dan diekspor memakai pembahasannya sendiri setelah pembaruan? |
| `editorial-roster.csv` | Butir mana yang harus dibaca penelaah pendidik dan bahasa, dan di mana mereka mencatat keputusannya? |
| `../../bank/oracle-by-level.json` | Berapa kunci dan langkah ekuivalen yang dinilai ulang dengan aritmetika rasional terpisah pada 60 level? |
| `../../bank/semantic-by-cell.json` | Batas operasi mana, nilai antara dan fixture negatif apa yang diuji untuk setiap kelompok? |
| `../../bank/independent-distribution-audit.json` | Apakah literal ekspresi menghasilkan nilai dan fingerprint yang diharapkan, dan apakah seluruh modul memenuhi kontrak? |
| `../../bank/determinism.json` | Apakah dua keluaran bersih memiliki kumpulan file dan byte yang sama? |

## Pelaksanaan ulang

Jalankan dari root hasil ekstraksi. Untuk perbandingan dengan rilis sebelumnya, arahkan argumen terakhir ke ZIP 1.0.0 asli.

```sh
npm run bank:build
python3 factory/build_bank.py --output /tmp/kalibataku-second/bank --evidence /tmp/kalibataku-second/evidence
python3 tests/bank/verify_bank.py --compare-bank /tmp/kalibataku-second/bank
node tools/audit-bank.mjs
python3 factory/export_recipes.py
python3 tests/bank/export_evidence.py
python3 tests/bank/strategy_fixtures.py
node tests/bank/snapshot_upgrade.mjs
python3 tests/bank/quarantine.py
python3 tests/bank/editorial_audit.py --baseline-zip /path/to/KALIBATAKU_STATIC_1.0.0_SOURCE_DIST_BANK_EVIDENCE.zip
```

Pengujian `snapshot_upgrade.mjs` memulihkan cadangan sintetis `tests/bank/legacy-v100-backup.json` yang dibuat dari aplikasi asli, lalu memeriksa draf dan peristiwa pada store sementara Node. Bukti ini mencakup upgrade kontrak dan isi snapshot. Uji browser untuk migrasi IndexedDB, cache setelah pembaruan dan perangkat offline tercatat tersendiri.

## Penelaahan manusia

Roster memuat 1.186 butir berbeda: tiga per keluarga untuk 394 keluarga, ditambah empat locator contoh audit. Satu contoh audit sudah termasuk dalam pilihan awal. Pemilihan tipikal menggunakan median fitur bilangan. Pilihan batas memprioritaskan penyebut, magnitudo dan rentang nilai antara. Pilihan beban pembahasan memprioritaskan jumlah langkah lalu panjang narasi dua bahasa. Setiap butir memiliki URL serta indeks berbasis nol ke ESM asli.

Penelaah membaca pertanyaan, petunjuk, penjelasan dan transformasi matematika di kedua bahasa. Kolom terakhir menampung identitas penelaah, tanggal, keputusan, catatan dan hasil uji ulang. Status review pendidik, pemeriksaan makna ID/EN dan pilot siswa masih `NOT_RUN`. Form A dan B memiliki histogram rancangan sepadan. Pengukuran kesukaran pada siswa memerlukan studi empiris tersendiri.
