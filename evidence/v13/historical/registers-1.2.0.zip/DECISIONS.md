# Keputusan rilis 1.2.0

**Kebijakan penilaian.** `visible-key-v2` membedakan respons sebelum dan sesudah penayangan kunci. `continuous-deadline-v2` menjalankan tenggat kecepatan sepanjang sesi. Pembukaan tinjauan selesai memiliki catatan perangkat tersendiri. Schema runtime kompatibel terdapat di `docs/contracts/core-1.2.schema.json`; spesifikasi sumber di `spec/` dipertahankan untuk verifikasi handoff asli.

**Anggaran renderer.** MathJax 4.1.3 berisi pengolah lokal dan glyph NewCM. Komponen MML/SVG resmi berukuran 1.702.534 byte sebelum kompresi, 571.290 byte dengan gzip-6. Pada alur uji, keseluruhan tambahan player beserta runtime berjumlah 613.534 byte (599,2 KiB gzip). Batas implementasi versi 1.2 ditetapkan 640 KiB gzip untuk kelompok tersebut. Batas lama 90 KiB tetap menghasilkan FAIL di AC-068. Worker dan peta ujaran yang disimpan untuk offline masuk inventaris per berkas. Halaman awal memuat shell dan menunda renderer hingga rumus diperlukan. Lihat `evidence/ux/performance/bundle-gzip.csv`.

**Aksesibilitas dan dokumen.** Rumus diproduksi dari AST berisi bilangan serta operator yang dikenal. Angka dan kunci dihitung dengan bilangan bulat presisi arbitrer. SVG disertai satu nama matematika ID/EN. Bentuk linear tetap tersedia ketika pemuatan gagal. PDF memakai vektor, DOCX menggunakan OMML, cetak HTML memakai notasi linear dengan pengelompokan.

**Riwayat keputusan sebelumnya**

# Keputusan implementasi 1.0.0

- **Distribusi ESM native.** Modul per fitur dan modul data mandiri per paket dapat dimuat browser secara langsung. Build Node/Python menyalin keluaran bersih dan memverifikasi sumber/bank. Pilihan ini menjaga jalur Git → hosting sederhana dan menghindari dependensi bundler dalam aplikasi.
- **Hash route dan URL relatif.** Navigasi menggunakan fragmen agar root maupun subfolder dilayani host statis dengan aturan 404 yang sederhana. Sesi memakai ID dan snapshot butir untuk pemulihan.
- **Nilai dan representasi.** Kunci disimpan sebagai numerator/denominator tereduksi. Literal soal mempertahankan representasi integer, desimal atau pecahan. Soal yang muncul di beberapa locale dan pertukaran ADD/MUL yang setara berbagi fingerprint. Batas delapan digit desimal pada schema dijaga dengan representasi pecahan eksak apabila diperlukan.
- **Pembahasan setara pada seluruh ekspresi.** Perubahan lokal pada operasi campuran ditulis kembali di dalam ekspresi lengkap. Strategi mencakup pembentukan puluhan, kompensasi, penyebut bersama, pencoretan faktor dan sifat distributif bila struktur soal mendukungnya.
- **Distribusi bank.** Seluruh modul soal aktual ikut dalam dist. Prefix versi publik mengikat URL immutable. Aset shell dapat direvalidasi. Origin LMS harus disetujui pada tahap server. Aset sendiri, cache pilihan dan font lokal memenuhi kebutuhan belajar tanpa ketergantungan CDN.
- **Simulasi dan bukti.** Hasil pribadi, demo sekolah dan status transport punya asal yang dapat ditelusuri. Preview dan eksportir memakai snapshot laporan yang sama. Kalibrasi siswa, deployment publik dan API LMS yang aktif dilaporkan tersendiri.

## Perubahan keputusan pada 1.1.0

- Rencana sesi yang sama memasok ringkasan setup dan pembuatan attempt. Paket baru disiapkan dan diperiksa terhadap manifest sebelum batas waktu dimulai. Sesi yang sedang berlangsung menggunakan snapshot semula.
- Revisi strategi mental yang mengubah byte bank mendapat versi baru dan URL baru. Cakupan serta identitas matematika diperiksa kembali terhadap setiap penempatan pada rilis asli.
- Browser yang menolak penyimpanan memerlukan pilihan sadar dari pengguna. Transaksi simpan mengikat snapshot dengan peristiwa jawaban dan finalisasi. Tampilan membedakan kegagalan simpan, salinan sesi untuk pemeriksaan dan cadangan yang dapat diimpor.
- Putusan 1.1 mengikuti 80 kriteria A5 dan 47 temuan audit baru. Bukti 1.0 disimpan terpisah. Pratinjau yang dapat dipasang, penerimaan produksi, pemahaman keluarga dan integrasi sekolah mempunyai persyaratan bukti yang berbeda.
