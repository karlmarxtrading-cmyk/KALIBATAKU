# KALIBATAKU 1.2.0 · Status rilis

**HOLD untuk produksi penuh.** Folder dist dapat dipasang dan diuji sekarang.

AC (80) · 64 PASS, 10 BLOCKED, 1 FAIL, 5 NOT_RUN. FM (48) · 41 PASS, 6 BLOCKED, 1 NOT_RUN. Register temuan mencakup 47 historis dan 19 dari audit ini.

| Lingkup | Status | Hasil |
|---|---|---|
| static_application | HOLD | Build statis lengkap untuk hosting. Penerimaan seluruh gate produksi mengikuti dua register. |
| bank_content | PASS | 4.604 paket, 177.640 penempatan, 168.142 ekspresi unik dan 386.834 langkah diperiksa. |
| bridge_contract | PASS | Kontrak, retry, ACK, isolasi dan pemulihan diuji memakai fixture. |
| live_lms | DEFERRED_BY_SCOPE | Endpoint sekolah, akun berperan dan verifikasi nilai server diperlukan. |
| pedagogical_calibration | NOT_PERFORMED | 1.186 sampel tersedia untuk penelaah yang memeriksa 394 keluarga template. |
| user_validation | NOT_PERFORMED | Pilot siswa, guru, operator dan orang tua belum dilakukan. |
| live_deployment | PREVIEW_PASS | HTTP/HTTPS root dan subfolder lulus di pratinjau lokal. Deployment publik memerlukan host pemilik. |

## Gate wajib yang masih terbuka

- **AC-030** · Perlu keyboard dan caret pada perangkat Android dan iOS fisik.
- **AC-045** · Perlu pendengar pembaca layar pada laporan HTML.
- **AC-053** · Perlu observasi salah ketuk serta jarak kontrol pada perangkat fisik.
- **AC-055** · Perlu perangkat Android dan IME sistem.
- **AC-056** · Perlu Safari iPhone/iPad dan Files pada perangkat fisik.
- **AC-057** · Perlu IME asli dengan composition pada perangkat sasaran.
- **AC-058** · Perlu rekaman ujaran NVDA, TalkBack dan VoiceOver.
- **AC-068** · Ambang 90 KiB perlu optimasi lebih lanjut atau penerimaan eksplisit atas anggaran 1.2.
- **AC-080** · Masih terdapat gate WAJIB_STATIC terbuka. Domain akhir juga belum diuji.
- **FM-038** · Android fisik.
- **FM-039** · Safari dan Files pada iPhone/iPad fisik.
- **FM-040** · IME fisik.
- **FM-041** · Pendengar NVDA.
- **FM-042** · Pendengar VoiceOver dan TalkBack.
- **FM-044** · Observasi sentuh fisik.

Build dist SHA-256 `08cac7c52d13761fffb67a2b45fd082fd3fc0c86883b6e02b912315cf7994314`.

[Buka indeks uji](evidence/00_HASIL_UJI.html)
