# Gate penerimaan yang masih terbuka

| Lingkup | Bukti yang tersedia | Yang diperlukan |
|---|---|---|
| Android dan iOS/iPadOS | Tiga engine desktop serta reflow aktual dari 320–1.440 px, tema, teks 200%, fokus dan keyboard | Jalankan pada ponsel fisik kedua platform. Rekam caret, composition, salah ketuk, perubahan orientasi, safe area dan penyimpanan hasil unduh. |
| Teknologi bantu | Nama rumus ID/EN, status teks, navigasi keyboard dan laporan HTML | Pendengar NVDA, VoiceOver dan TalkBack menguji ujaran, jeda, perubahan fokus serta pemahaman rumus. PDF keluarga memakai teks vektor. Verifikasi aksesibilitas PDF bertag belum dilakukan. |
| Kinerja | Anggaran dasar, ukuran file, angka laboratorium, cache dan daftar request | Tambahan player dengan renderer melampaui batas 90 KiB gzip dari AC-068. Tim mencatat anggaran 1.2 sebesar 640 KiB. Penerimaan perubahan anggaran dan pengukuran pada perangkat sasaran masih terbuka. p75 memerlukan trafik produksi. |
| Kurikulum dan UX | Oracle eksak seluruh bank, roster dan protokol pilot | Perlu penelaah matematika serta bahasa, siswa, guru, operator dan orang tua. Kalibrasi kesulitan dan pemahaman laporan bergantung pada hasil peserta. |
| Deployment dan LMS institusi | HTTP/HTTPS lokal root/subfolder, 404/MIME; simulasi, kontrak, antrean serta ACK | Smoke, rollback dan unduhan pada domain akhir. Untuk LMS, sediakan endpoint staging serta akun lintas peran dan kelas yang memiliki izin uji. |
 
Gunakan [protokol penerimaan](evidence/v12/input/04_RENCANA_PENUTUPAN_PRODUKSI.md), [roster editorial](evidence/v12/bank/editorial-roster.csv) dan [register lengkap](STATUS_RILIS.md). Untuk setiap hasil eksternal, simpan versi browser/OS, perangkat, tanggal, ID build dan observasi aktual.
