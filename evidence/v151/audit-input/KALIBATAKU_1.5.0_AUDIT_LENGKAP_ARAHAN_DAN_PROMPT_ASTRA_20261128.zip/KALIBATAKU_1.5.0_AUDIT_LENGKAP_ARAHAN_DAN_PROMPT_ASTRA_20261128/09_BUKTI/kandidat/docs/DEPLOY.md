# Memasang KALIBATAKU 1.5.0 (petualangan) di Cloudflare Pages

ZIP rilis memiliki satu root proyek. Ekstrak di komputer Anda. Di root itu ada `package.json`, `src`, `factory`, `dist`, `tools`, `tests`, `docs` dan `evidence`. **Folder yang dipublikasikan adalah `dist/`.** Di dalam `dist/` ada aplikasi, bank soal 1.2 (`dist/bank/`, 4.677 berkas, tidak berubah) dan metadata perjalanan (`dist/journey/v1/`). Simpan ZIP rilis di luar repository supaya tidak ikut terunggah.

Tidak ada variabel lingkungan, kunci API, layanan berbayar, atau server yang diperlukan. Aplikasi statis; data siswa tetap di perangkat (IndexedDB).

## Git Bash menuju GitHub

Untuk repositori publik, gunakan cabang validasi dan salin hanya direktori `dist/` dari ZIP ke checkout. Seluruh source, bukti, fixture dan hasil ekspor dapat disimpan bersama dalam ZIP atau repositori privat. Periksa bahwa situs dari cabang publik hanya menyajikan direktori keluaran. File yang sudah pernah masuk riwayat repositori publik perlu ditinjau oleh pemilik repositori.

```bash
# Jalankan release:verify di folder hasil ekstraksi sebelum menyalin dist.
npm run release:verify
# Di checkout GitHub yang dituju, setelah menyalin dist:
git status
git switch -c validasi/kalibataku-1.5.0
git add -A -- dist/
git diff --cached --stat
git commit -m "KALIBATAKU 1.5.0 untuk validasi"
git push -u origin validasi/kalibataku-1.5.0
```

Untuk alur ini, gunakan build command kosong dan output directory `dist`. Untuk membangun ulang dari source, siapkan repositori privat berisi root proyek lengkap sesuai ZIP. Jalankan `npm run build` pada pilihan build di bawah. Gunakan preview deployment untuk kandidat HOLD. Pemilik rilis memutuskan promosi ke produksi setelah persyaratan penerimaan terpenuhi.

## B · Cloudflare Pages dengan integrasi Git

1. Cloudflare → Workers & Pages → Create → Pages → Connect to Git → pilih repository.
2. *Production branch*: `main`. *Root directory*: kosong (atau nama subfolder bila root proyek ada di subfolder repository).
3. *Framework preset*: **None**.
4. Dua pilihan konfigurasi build — pilih salah satu:
   - **Menyajikan build yang sudah diuji (disarankan):** *Build command* kosong, *Build output directory* `dist`. Yang tersaji persis `dist/` yang hash-nya tercatat di `RELEASE_STATUS.json` (`dist_tree_sha256`).
   - **Membangun ulang tiap push:** *Build command* `npm run build`, *Build output directory* `dist`. Perlu Node 22 atau lebih baru dan Python 3.11 atau lebih baru (`python3`). Build tidak memakai paket npm (lockfile tanpa dependensi) dan tidak membangkitkan ulang bank; build memeriksa pin bank lalu menyalin `src/` ke `dist/`. Hasilnya identik dengan dist rilis (bukti `evidence/v15/qa/clean-build-twice/`).
5. *Environment variables*: tidak ada yang diperlukan.
6. Save and Deploy. Catat URL `*.pages.dev` dan *deployment ID* di catatan operator Anda.


## C · Alternatif: unggah `dist/` dengan Wrangler

```bash
npx wrangler login
npx wrangler pages project create <nama-proyek>     # sekali untuk proyek baru
npx wrangler pages deploy dist --project-name <nama-proyek>
```

## D · Pemeriksaan setelah deploy

```bash
BASE='https://NAMA-PROYEK.pages.dev/'
curl -s "$BASE"build-info.json                     # {"app_version":"1.5.0","bank_version":"1.2.0",...}
curl -s "$BASE"offline-assets.json | head -c 40     # "release" harus sama dengan RELEASE_STATUS.json → offline_release
curl -sI "$BASE"journey/v1/route.json | grep -i -E 'content-type|cache-control'
curl -sI "$BASE"journey/journey.mjs | grep -i content-type          # text/javascript
curl -sI "$BASE"bank/v1.2/g01/l01/MM-G01-L01-ADD-P001.mjs | grep -i cache-control   # immutable
curl -s -o /dev/null -w '%{http_code}\n' "$BASE"tidak-ada.html     # 404
```

Lalu di browser: buka beranda (profil baru → “Mulai dari dasar”), jawab satu misi sampai “Lihat hasil”, buka “Misi berikutnya”, tutup tab di tengah misi, buka lagi → “Lanjutkan petualangan” harus membuka soal yang sama. Di Peta, pilih “Simpan misi untuk offline”, putuskan jaringan, lanjutkan misi. Catat hasilnya di `docs/PROTOKOL_EKSTERNAL_1.5.md` bagian REL-02.


## Pembaruan dan rollback

1. Cadangkan profil uji. Buka ZIP melalui preview pemulihan dan catat jumlah sesi, event, record dan status draf. Simpan arsip di luar repo.
2. Pada preview domain yang diotorisasi, periksa HTTPS, 404, MIME, header, rute dan subfolder yang benar. Cocokkan build-info.json dan release dalam offline-assets.json dengan RELEASE_STATUS.json. Verifikasi byte dist sesuai manifest. Jangan mengirim data siswa.
3. Gunakan dua tab dengan sesi aktif. Publikasikan pembaruan yang disetujui, selesaikan satu jawaban di tab lama, lalu tutup semua tab dan buka kembali. Periksa nomor rilis, draf, urutan soal, feedback dan jumlah finalisasi dalam keadaan online dan offline.
4. Untuk rollback produksi yang sudah disetujui, pilih deployment produksi tersimpan yang pernah berhasil di menu Deployments. Konfirmasi URL dan ID target. Buka kembali sesi yang dibuat sebelum serta sesudah pembaruan. Periksa riwayat dan snapshot sebelum mengizinkan pemakaian umum. Jika domain preview membutuhkan versi terdahulu, bangun kembali revisi tersebut pada cabang preview sesuai proses operator.
5. Rekam ID deployment dan waktu sebelum/sesudah, hash yang benar-benar tersaji serta hasil pemeriksaan profil. Bukti untuk REL-02 dan REL-03 harus berasal dari target yang digunakan.

## Dokumentasi operator

[Integrasi Git dengan Cloudflare Pages](https://developers.cloudflare.com/pages/get-started/git-integration/)

[Rollback Cloudflare Pages](https://developers.cloudflare.com/pages/configuration/rollbacks/)
