from pathlib import Path
import argparse,json,sys,traceback
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright

parser=argparse.ArgumentParser(description='Independent Firefox audit probe; source files stay unchanged.')
parser.add_argument('--root',type=Path,required=True,help='Extracted KALIBATAKU source directory containing dist and tests')
parser.add_argument('--out',type=Path,required=True,help='Auditor output directory outside the source tree')
parser.add_argument('--firefox-exe',help='Optional Playwright-compatible Firefox executable')
parser.add_argument('--screenshots',action='store_true',help='Internal QA only; excluded from public audit deliverables')
args=parser.parse_args()
ROOT=args.root.resolve()
OUT=args.out.resolve()
if OUT==ROOT or ROOT in OUT.parents: parser.error('--out must be outside the immutable source tree')
OUT.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'tools'))
from qa_core import tree_hash
build=json.loads((ROOT/'dist/build-info.json').read_text())
build['offline_release']=json.loads((ROOT/'dist/offline-assets.json').read_text())['release']
build['dist_tree_sha256']=tree_hash(ROOT/'dist')
sys.path.insert(0,str(ROOT/'tests/journey'))
from offline_origin import TestOrigin
from offline_capability import catalog_install

origin=TestOrigin(ROOT/'dist')
report={'scenario':'Install one package through catalog UI; corrupt one cached package byte; compare map, catalog list, offline management and launch', 'started':datetime.now(timezone.utc).isoformat(),'checks':[]}
report['build']=build
try:
 with sync_playwright() as pw:
  browser=pw.firefox.launch(executable_path=args.firefox_exe)
  report['browser']=browser.version
  ctx=browser.new_context(viewport={'width':390,'height':844})
  page=ctx.new_page();page.set_default_timeout(12000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(origin.url);page.locator('[data-cta=adventure]').wait_for()
  catalog_install(page,origin.url,'MM-G01-L01-ADD-P001')
  pack=page.evaluate('''async()=>{
    const m=await import('./data/offline.js');const r=(await m.inspectInstalled()).find(r=>r.id==='MM-G01-L01-ADD-P001');
    if(!r)throw Error('P001 missing');const c=await caches.open(r.packCache);const bytes=new Uint8Array(await(await c.match(r.url)).arrayBuffer());
    const before=bytes[0];bytes[0]^=1;await c.put(r.url,new Response(bytes));return {id:r.id,url:r.url,before,after:bytes[0]};
  }''')
  report['mutation']=pack
  origin.network(False,ctx,'firefox')
  page.goto(origin.url+'#/map');page.reload();page.locator('.offline-mission [data-offline-state=repair]').wait_for()
  report['map_state']=page.locator('.offline-mission').inner_text()
  page.goto(origin.url+'#/packs?grade=1&level=1&op=ADD')
  row=page.locator('.pack-row[href*="ADD-P001"]')
  row.wait_for();report['catalog_row']=row.inner_text()
  report['catalog_href']=row.get_attribute('href')
  if args.screenshots: page.screenshot(path=str(OUT/'catalog_corrupt_offline.png'))
  page.goto(origin.url+'#/offline?grade=1&level=1&op=ADD&pack='+pack['id'])
  page.get_by_role('button',name='Perbaiki salinan offline',exact=True).wait_for()
  report['offline_management']=page.locator('main').inner_text()
  if args.screenshots: page.screenshot(path=str(OUT/'offline_corrupt_management.png'))
  page.goto(origin.url+'#/packs?grade=1&level=1&op=ADD')
  page.locator('.pack-row[href*="ADD-P001"]').click()
  page.locator('form.setup').wait_for()
  report['setup']=page.locator('main').inner_text()
  buttons=page.locator('form.setup button');report['setup_buttons']=buttons.all_text_contents()
  launch=page.locator('form.setup button.primary')
  if launch.count():
   report['launch_disabled']=launch.is_disabled()
   if launch.is_enabled():
    launch.click();page.wait_for_timeout(1800);report['after_launch']=page.locator('main').inner_text()
  report['page_errors']=errors
  report['finding_confirmed']='Tersedia offline' in report['catalog_row'] and 'Siap untuk latihan' in report['offline_management'] and 'Perbaiki salinan offline' in report['offline_management'] and report.get('launch_disabled') is True
  browser.close()
except Exception:
 report['error']=traceback.format_exc()
finally:
 origin.close()
 report['finished']=datetime.now(timezone.utc).isoformat()
 (OUT/'probe_catalog_offline.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2)[:12000])

if report.get('error') or not report.get('finding_confirmed'): raise SystemExit(1)
