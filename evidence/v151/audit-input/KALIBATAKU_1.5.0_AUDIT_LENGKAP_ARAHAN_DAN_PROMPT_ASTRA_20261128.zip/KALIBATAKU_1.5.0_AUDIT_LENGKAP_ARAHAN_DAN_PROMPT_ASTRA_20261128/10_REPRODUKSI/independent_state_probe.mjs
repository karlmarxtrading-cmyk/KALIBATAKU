// Audit probe only. Source and application storage are never written.
// node independent_state_probe.mjs --root /path/to/source --out /path/to/audit-output
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const arg=name=>{const at=process.argv.indexOf(name);return at<0?null:process.argv[at+1];};
const root=arg('--root')?pathToFileURL(resolve(arg('--root'))+'/'):new URL('../source/',import.meta.url);
const out=arg('--out')?pathToFileURL(resolve(arg('--out'))+'/'):new URL('./',import.meta.url);
await mkdir(out,{recursive:true});
const {journeyState,nextMission,planMission,exposure,missionOutcome}=await import(new URL('src/journey/model.mjs',root));
const {journeySummary}=await import(new URL('src/journey/report.mjs',root));
const {createAttempt,begin,visit,editDraft,submit,finish,clearResponse,noteHint}=await import(new URL('src/player/engine.mjs',root));
const route=JSON.parse(await readFile(new URL('src/journey/v1/route.json',root)));
const nodeId='arithmetic.addition.g01.l01';
const node=route.nodes.find(n=>n.competency_id===nodeId);
const shard=JSON.parse(await readFile(new URL(node.occ.url.replace('journey/','src/journey/'),root)));
const level=JSON.parse(await readFile(new URL('dist/bank/g01/l01.json',root)));
const refs=new Map(level.competencies.flatMap(c=>c.packages).map(p=>[p.package_id,p]));
let time=Date.UTC(2026,10,28,0);const tick=()=>time+=1000;
const scope={profileId:'00000000-0000-4000-8000-000000000123',origin:'local_practice'};
const record=[];
async function mission(attempts,kind,mode){
 const state=journeyState(route,attempts),progress=state.nodes.get(nodeId);
 const plan=planMission({shard,kind,policy:route.mission_policy,seen:exposure(attempts,nodeId),progress,seed:123+attempts.length});
 const ref=refs.get(plan.package.package_id);
 const pkg=(await import(new URL('dist/'+ref.url,root))).default;
 const items=plan.rows.map(r=>({question:pkg.questions[r.index],journey_role:r.role,journey_band:r.band,journey_review:r.review,occurrence_ref:{package_id:pkg.package_id,package_sha256:ref.sha256,content_version:pkg.content_version,question_index:r.index,question_id:pkg.questions[r.index].question_id,question_revision:pkg.questions[r.index].question_revision}}));
 const journey={journey_id:'kalibataku-adventure',node_id:nodeId,stage_id:node.stage_id,mission_kind:kind,metadata_version:route.metadata_version,route_version:route.route_version,policy_version:route.mission_policy.policy_version,journey_policy:'journey-policy-1.1.0',feature_policy:route.feature_policy,seed:plan.trace.seed,readiness_rule:{target_missions:2,min_rate:.8,coverage_needed:12,strategies_needed:2,label:'product_policy_not_psychometric'},selected_occurrence_refs:items.map(i=>i.occurrence_ref),selection_trace:plan.trace};
 const a=createAttempt(pkg,scope,{mode:'practice',items,journey,seed:plan.trace.seed,now:tick()});begin(a,tick());
 if(mode!=='finish_at_first_question'){
  for(let i=0;i<a.items.length;i++){
   const item=a.items[i];
   if(mode==='targets_only'&&item.journey_role==='a')break;
   visit(a,i,tick());
   if(mode==='targets_only'&&item.journey_role==='w'){clearResponse(a,i,true);continue;}
   if(mode==='all_hints')noteHint(a,i);
   const answer=item.question.answer;
   const n=BigInt(answer.numerator)+(mode==='all_wrong'?BigInt(answer.denominator):0n);
   editDraft(a,i,answer.denominator==='1'?String(n):n+'/'+answer.denominator,'id');
   submit(a,i,tick());
  }
 }
 finish(a,{now:tick()});attempts.push(a);
 const after=journeyState(route,attempts),s=after.nodes.get(nodeId);
 const viewed=new Set(attempts.flatMap(x=>x.items.filter(i=>i.seen).map(i=>i.question.fingerprint)));
 const answered=new Set(attempts.flatMap(x=>x.items.filter(i=>i.history.length).map(i=>i.question.fingerprint)));
 return {mode,kind,package_id:a.package_id,outcome:missionOutcome(a),seen_now:a.items.filter(i=>i.seen).length,unseen_now:a.items.filter(i=>!i.seen).length,
  actual_unique_viewed:viewed.size,actual_unique_answered:answered.size,reported_coverage:s.coverage,coverage_needed:s.coverage_needed,passing_missions:s.passing.size,strategies_seen:s.strategies_seen,ready:s.ready,next:nextMission(route,after),attempt:a};
}
const sparse=[];
for(const mode of ['finish_at_first_question','targets_only','targets_only']){
 const kind=sparse.length?nextMission(route,journeyState(route,sparse)).kind:'intro';
 const result=await mission(sparse,kind,mode);const {attempt,...summary}=result;record.push(summary);
}
const controls=[];
for(const mode of ['all_wrong','all_hints','all_correct']){
 const attempts=[];
 for(const kind of ['intro','regular','regular']){const {attempt,...r}=await mission(attempts,kind,mode);controls.push(r);}
}
const teacher=journeySummary(sparse).rows.find(r=>r.node_id===nodeId);
const final=record.at(-1);
const report={method:'Independent behavioral cases using supplied real bank, selector and player engine; human-observable seen/history counted independently',source:'src/journey/model.mjs',
 source_root:root.pathname,runtime:process.version,seed_base:123,
 expected_policy:'Unseen assigned questions must not count as unique_seen. At minimum actual viewed coverage must reach coverage_needed before readiness.',
 sparse_completion:record,teacher_summary:teacher,controls,
 counterexample_reproduced:record[0].reported_coverage>record[0].actual_unique_viewed&&final.ready&&final.actual_unique_viewed<final.coverage_needed&&teacher.ready&&teacher.unique_seen===final.reported_coverage,
 all_snapshots_completed:sparse.every(a=>a.status==='completed')};
await writeFile(new URL('independent_state_probe.json',out),JSON.stringify(report,null,2)+'\n');
await writeFile(new URL('sparse_completion_attempts.json',out),JSON.stringify(sparse,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
