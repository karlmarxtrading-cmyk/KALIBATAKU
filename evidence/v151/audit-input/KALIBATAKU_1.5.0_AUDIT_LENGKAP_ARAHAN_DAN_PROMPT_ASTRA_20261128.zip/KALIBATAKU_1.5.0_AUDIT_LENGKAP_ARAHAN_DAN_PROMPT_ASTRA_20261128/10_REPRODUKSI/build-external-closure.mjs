import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {Workbook} from '@oai/artifact-tool';

const source=process.argv[2]||'/workspace/scratch/71e44cfb51b4/kalibataku_audit_1_5/source';
const outputDir=process.argv[3]||'/workspace/scratch/71e44cfb51b4/kalibataku_audit_1_5/agent_data/external_closure';
await fs.mkdir(outputDir,{recursive:true});
const imported=await Workbook.fromCSV(await fs.readFile(path.join(source,'REGISTER_AC_FINAL.csv'),'utf8'),{sheetName:'Source'});
const original=imported.worksheets.getItem('Source').getUsedRange().values;
const [keys,...records]=original;
const byId=new Map(records.map(r=>{const obj=Object.fromEntries(keys.map((k,i)=>[k,r[i]??'']));return [obj.id,obj];}));
// Roles below identify required resources, never people who already performed tests.
const tasks=[
 ['BANK-07','Guru SD/SMP/SMA; penelaah ID/EN','Roster dan rute build dibekukan','Tinjau tiga posisi setiap keluarga; catat keputusan; selesaikan revisi dan retest.','394 keluarga lengkap; kasus batas, urutan dan bahasa disetujui penelaah.','Roster berisi penelaah, tanggal, keputusan, alasan, tindak lanjut dan bukti retest.','41–44'],
 ['UX-09','Android fisik + iPhone/iPad; operator QA','Keyboard sistem terbuka; build sama','Potret/lanskap: pecahan, feedback, Lanjut, pulihkan draf, ketuk ganda.','Input/OKE/Lanjut terlihat; draf utuh; satu commit final.','Rekaman setiap OS/orientasi; model keyboard, bahasa, hasil dan jumlah commit.','5–7'],
 ['A11Y-04','Penguji NVDA, VoiceOver, TalkBack','Perangkat/OS/browser dan bahasa ID/EN dicatat','Dengarkan rumus, feedback, peta, bantuan, hasil dan galat 1/0.','Makna rumus, urutan fokus/status/error benar pada seluruh kombinasi wajib.','Audio atau transkrip ujaran aktual, langkah, hasil, versi pembaca layar dan retest.','24–31'],
 ['DEVICE-02','Android + Chrome; Gboard + IME lain; QA','Cadangan profil sintetis; paket offline','Jalankan langkah perangkat B: input, IME, rotasi, ketukan, unduh/restore, offline, buka ulang.','Caret/draf utuh; komposisi Enter tidak mengirim; salah ketuk ≤1/20; alur selesai.','Model Android/OS/browser/IME; rekaman, berkas cadangan, hasil lintas perangkat.','13–23'],
 ['DEVICE-03','iPhone/iPad fisik + Safari; QA','Files tersedia; cadangan dan paket offline','Jalankan langkah B; periksa safe-area, keyboard, Files dan restore lintas perangkat.','Kontrol terlihat; draf/riwayat utuh; salah ketuk ≤1/20; alur selesai.','Model iPhone/iPad/iOS/Safari; rekaman orientasi, unduh/restore dan offline.','13–23'],
 ['TEACH-03','Penelaah + Microsoft Word sekolah','Fixture pecahan dan DOCX baru dari kandidat','Buka di Word; bandingkan setiap persamaan dengan HTML/PDF dan rujukan JSON.','Semua pembilang, penyebut, kurung dan tanda benar di aplikasi sasaran.','DOCX, versi Word/OS, tangkapan render aktual, tabel perbandingan dan keputusan.','33–39'],
 ['PILOT-01','12 siswa; moderator; sekolah/orang tua','Izin sesuai aturan; tiga kelompok materi; alias','Lima tugas siswa tanpa arahan filter; catat waktu, bantuan, kebingungan dan kesalahan.','≥11/12 mulai+lanjut mandiri; nol kehilangan data kritis/jalan buntu.','12 formulir anonim, kelompok materi, hasil tiap tugas dan catatan bantuan moderator.','46–51'],
 ['PILOT-02','3 guru; moderator','Laporan kandidat memuat mandiri dan revisi','Cari kesulitan siswa; bedakan mandiri/revisi; tentukan arah lanjut.','3/3 memahami perbedaan respons mandiri dan revisi setelah kunci.','Tiga formulir anonim, jawaban aktual, bantuan moderator dan keputusan.','46–51'],
 ['PILOT-03','Pengembang + moderator + penelaah','PILOT-01/02 benar-benar dilaksanakan','Kelompokkan temuan; perbaiki masalah; uji ulang tugas dan peserta terdampak.','Log anonim terhubung ke tindakan dan retest; blocker terselesaikan.','Daftar temuan, perubahan, build sebelum/sesudah, hasil retest serta penelaahan.','46–51'],
 ['REL-02','Operator hosting/domain; penanggung jawab rilis','Akses target nyata dan kandidat terverifikasi','Pada domain tujuan: HTTPS, route/subpath, MIME, header, 404, versi dan hash.','Build tersaji cocok dengan kandidat dan perilaku HTTP yang disyaratkan.','URL target, deployment ID, waktu, HTTP headers/body, build-info dan hash aktual.','57–60'],
 ['REL-03','Operator hosting; QA pada dua perangkat','Target nyata; deployment lama/baru tersedia','Simpan offline; update saat sesi aktif; tutup tab; rollback; periksa riwayat dan misi.','Sesi lama selesai; SW baru aktif sesuai siklus; data dan offline tetap dapat digunakan.','ID/hash deployment sebelum/sesudah/rollback; rekaman dua perangkat dan hasil data.','57–62'],
 ['PERF-03','Operator pengukuran; peserta nyata','Setelah pilot dan deployment; izin pengumpulan','Kumpulkan observasi nyata; dokumentasikan populasi/periode; hitung p75.','LCP ≤2,5 s; INP ≤200 ms; CLS ≤0,1; tanpa data tetap NOT_RUN.','Data anonim, ukuran sampel, periode, versi instrumen, perhitungan p75 dan build.','53–55']
];
const headers=['ac_id','fase','status_paket','persyaratan_asli','sumber_daya_dan_penanggung_jawab','prasyarat','langkah_uji','kriteria_lulus_asli','kriteria_operasional','bukti_aktual_yang_diperlukan','hasil_baru','pelaksana_aktual','receipt_aktual','rujukan'];
const rows=tasks.map(([id,owner,pre,steps,acceptance,evidence,lines])=>{
 const r=byId.get(id);assert(r,id);
 return [r.namespace_id,r.fase,r.hasil_aktual,r.persyaratan,owner,pre,steps,r.bukti_lulus,acceptance,evidence,'','','','REGISTER_AC_FINAL.csv '+r.namespace_id+'; docs/PROTOKOL_EKSTERNAL_1.5.md:'+lines];
});
assert.equal(rows.filter(r=>r[1]==='WAJIB').length,11);
assert.equal(rows.filter(r=>r[1]==='WAJIB'&&r[2]==='BLOCKED').length,8);
assert.equal(rows.filter(r=>r[1]==='WAJIB'&&r[2]==='NOT_RUN').length,3);
assert.equal(rows.at(-1)[0],'AC:PERF-03');assert.equal(rows.at(-1)[1],'SETELAH_PILOT');
const workbook=Workbook.create(),sheet=workbook.worksheets.add('Gate eksternal');
sheet.getRange('A1:N13').values=[headers,...rows];sheet.showGridLines=false;
sheet.getRange('A1:N13').format.font={name:'Arial',size:11};
sheet.getRange('A1:N1').format={fill:'#263F5B',font:{name:'Arial',bold:true,color:'#FFFFFF'},rowHeight:28};
sheet.getRange('A1:C13').format.columnWidth=24;
sheet.getRange('A2:N13').format.rowHeight=24;
sheet.freezePanes.freezeRows(1);
workbook.recalculate();
const actual=sheet.getRange('A1:N13').values;assert.deepEqual(actual,[headers,...rows]);
const csv=actual.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n';
await fs.writeFile(path.join(outputDir,'MATRIX_11_GATE_EKSTERNAL.csv'),'\ufeff'+csv);
const preview=await workbook.render({sheetName:'Gate eksternal',range:'A1:C13',scale:1.5,format:'png'});
await fs.writeFile('/tmp/kalibataku-external-closure-71e44cfb/matrix-status-preview.png',new Uint8Array(await preview.arrayBuffer()));
const inspection=await workbook.inspect({kind:'table',range:"'Gate eksternal'!A1:C13",include:'values',tableMaxRows:13,tableMaxCols:3,maxChars:4000});
await fs.writeFile('/tmp/kalibataku-external-closure-71e44cfb/matrix-inspection.ndjson',inspection.ndjson);
const rosterPath='evidence/v15/review/roster-394-templates.csv';
const rosterBytes=await fs.readFile(path.join(source,rosterPath));
const roster=await Workbook.fromCSV(rosterBytes.toString('utf8'),{sheetName:'Roster'});
const [rosterKeys,...rosterRows]=roster.worksheets.getItem('Roster').getUsedRange().values;
assert.equal(rosterRows.length,394);
for(const key of ['reviewer_name','reviewer_role','reviewed_at','decision','notes']){
 const index=rosterKeys.indexOf(key);assert(index>=0);assert(rosterRows.every(r=>!r[index]));
}
await fs.writeFile(path.join(outputDir,'ROSTER_394_TEMPLATE_BELUM_DIREVIEW.csv'),rosterBytes);
const digest=crypto.createHash('sha256').update(rosterBytes).digest('hex');
await fs.writeFile(path.join(outputDir,'ASAL_ROSTER.txt'),`SALINAN SUMBER, BELUM ADA REVIEW MANUSIA\n\nAsal: ${rosterPath} di KALIBATAKU_1.5.0_KANDIDAT_HOLD.zip.\nSHA-256 roster: ${digest}\n394 baris, seluruh reviewer_name, reviewer_role, reviewed_at, decision dan notes kosong.\nSalinan byte-identik. Pertama/median/tersulit adalah tiga posisi review per keluarga, bukan jaminan tiga butir unik. Gunakan roster yang diregenerasi bila metadata rute atau bank berubah.\n`);
console.log(JSON.stringify({status:'PASS',mandatory:11,blocked:8,not_run:3,after_pilot:1,roster_rows:394,roster_review_fields_empty:true,outputDir},null,2));
