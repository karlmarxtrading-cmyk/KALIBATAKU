from pathlib import Path
import argparse,json,sys,traceback
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright
parser=argparse.ArgumentParser(description='Independent Firefox audit probe; source files stay unchanged.')
parser.add_argument('--root',type=Path,required=True,help='Extracted KALIBATAKU source directory containing dist and tests')
parser.add_argument('--out',type=Path,required=True,help='Auditor output directory outside the source tree')
parser.add_argument('--firefox-exe',help='Optional Playwright-compatible Firefox executable')
parser.add_argument('--screenshots',action='store_true',help='Internal QA only; excluded from public audit deliverables')
args=parser.parse_args()
ROOT=args.root.resolve()
OUT=args.out.resolve()
if OUT==ROOT or ROOT in OUT.parents: parser.error('--out must be outside the immutable source tree')
OUT.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'tools'))
from qa_core import tree_hash
build=json.loads((ROOT/'dist/build-info.json').read_text())
build['offline_release']=json.loads((ROOT/'dist/offline-assets.json').read_text())['release']
build['dist_tree_sha256']=tree_hash(ROOT/'dist')
sys.path.insert(0,str(ROOT/'tests/journey'))
from offline_origin import TestOrigin
origin=TestOrigin(ROOT/'dist')
report={'started':datetime.now(timezone.utc).isoformat(),'scenario':'New intro mission, end from first unanswered question, inspect map coverage'}
report['build']=build
try:
 with sync_playwright() as pw:
  browser=pw.firefox.launch(executable_path=args.firefox_exe);report['browser']=browser.version
  ctx=browser.new_context(viewport={'width':390,'height':844});p=ctx.new_page();p.set_default_timeout(15000)
  p.goto(origin.url);p.locator('[data-cta=adventure]').click();p.locator('.kp-answer').wait_for()
  aid=p.url.split('#/session/')[1]
  p.locator('[data-part=review]').click();p.locator('[data-part=finish]').wait_for()
  report['confirmation']=p.locator('main').inner_text()
  p.locator('[data-part=finish]').click();p.locator('.mission-result').wait_for()
  report['result']=p.locator('.mission-result').inner_text()
  report['state']=p.evaluate('''async aid=>{
    const s=await import('./data/store.js'),j=await import('./journey/journey.mjs');
    const a=await s.getAttempt(aid,s.activeScope()),o=await j.overview(s.activeScope());
    const n=o.state.nodes.get(a.journey.node_id);
    return {attempt_id:aid,status:a.status,items:a.items.map(i=>({id:i.question.question_id,seen:i.seen,history:i.history.length,final_status:i.final_status})),coverage:n.coverage,coverage_needed:n.coverage_needed,passing:n.passing.size,strategies:n.strategies_seen,ready:n.ready};
  }''',aid)
  p.goto(origin.url+'#/map');p.locator('.map-stage').first.wait_for();report['map_node']=p.locator('.map-node').first.inner_text()
  if args.screenshots: p.screenshot(path=str(OUT/'unseen_coverage_map.png'))
  state=report['state']
  report['finding_confirmed']=state['coverage']==6 and sum(bool(i['seen']) for i in state['items'])==1 and sum(i['history'] for i in state['items'])==0
  browser.close()
except Exception:report['error']=traceback.format_exc()
finally:
 origin.close();report['finished']=datetime.now(timezone.utc).isoformat()
 (OUT/'probe_unseen_coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))

if report.get('error') or not report.get('finding_confirmed'): raise SystemExit(1)
