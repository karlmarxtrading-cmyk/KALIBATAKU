from pathlib import Path
import subprocess, os, time, json, hashlib, argparse

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description='Run selected source checks without changing source artifacts.')
parser.add_argument('--root', type=Path, default=HERE.parent / 'source')
parser.add_argument('--out', type=Path, default=HERE)
args = parser.parse_args()
OUT = args.out.resolve()
SOURCE = args.root.resolve()
OUT.mkdir(parents=True, exist_ok=True)
commands = [
 ('bank-preservation',['python3','tools/bank-preservation.py']),
 ('journey-sidecar',['python3','tools/build-journey.py','--check']),
 ('progression-bounds',['node','tests/journey/progression-bounds.mjs',str(OUT/'progression-bounds.json')]),
 ('progression-launch',['node','tests/journey/progression-launch.mjs','--out',str(OUT/'progression-launch.json')]),
 ('start-intent',['node','tests/journey/start-intent.test.mjs']),
]
receipts=[]
for name, command in commands:
    started=time.time()
    r=subprocess.run(command,cwd=SOURCE,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    log=OUT/(name+'.log')
    log.write_text(r.stdout+r.stderr)
    receipt={'name':name,'command':command,'cwd':str(SOURCE),'exit_code':r.returncode,'seconds':round(time.time()-started,2),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    receipts.append(receipt)
    print(json.dumps(receipt),flush=True)
(OUT/'source_check_receipts.json').write_text(json.dumps(receipts,indent=2))
raise SystemExit(1 if any(r['exit_code'] for r in receipts) else 0)
