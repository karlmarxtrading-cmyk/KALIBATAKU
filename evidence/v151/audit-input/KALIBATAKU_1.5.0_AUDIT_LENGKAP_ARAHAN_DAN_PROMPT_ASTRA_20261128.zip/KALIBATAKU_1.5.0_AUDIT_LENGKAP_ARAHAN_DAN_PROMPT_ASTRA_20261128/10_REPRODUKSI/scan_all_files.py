"""Independent whole-archive inventory and structural integrity audit."""
from pathlib import Path
import ast, collections, csv, gzip, hashlib, io, json, re, zipfile
from lxml import etree
from PIL import Image
import fitz

import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
ROOT=args.root.resolve()
OUT=args.out.resolve()
if OUT == ROOT or ROOT in OUT.parents: parser.error('--out must be outside source')
OUT.mkdir(parents=True,exist_ok=True)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def group(rel):
    if rel.startswith('dist/bank/'):
        return 'Bank soal publik'
    if rel.startswith(('src/vendor/', 'dist/vendor/')):
        return 'Dependensi/aset vendor'
    if rel.startswith('dist/'):
        return 'Distribusi aplikasi'
    if rel.startswith('src/'):
        return 'Sumber aplikasi'
    if rel.startswith('evidence/'):
        return 'Bukti bawaan kandidat'
    if rel.startswith(('tests/', 'tools/')):
        return 'Pengujian dan peralatan'
    if rel.startswith(('spec/', 'factory/')):
        return 'Kurikulum dan pembangkit bank'
    return 'Dokumentasi dan metadata rilis'


def validate(path, data):
    suffix = path.suffix.lower()
    if suffix in ('.json', '.webmanifest'):
        obj = json.loads(data)
        return 'JSON_PARSE_PASS'
    if suffix == '.mjs' and data.startswith(b'export default {'):
        json.loads(data.decode('utf-8')[len('export default '):].strip().rstrip(';'))
        return 'DATA_MODULE_JSON_PASS'
    if suffix == '.py':
        ast.parse(data, str(path))
        return 'PYTHON_PARSE_PASS'
    if suffix in ('.zip', '.docx', '.xlsx'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            bad = z.testzip()
            if bad: raise ValueError('CRC failure: ' + bad)
            if suffix in ('.docx', '.xlsx'):
                for name in z.namelist():
                    if name.endswith(('.xml', '.rels')):
                        etree.fromstring(z.read(name), parser=etree.XMLParser(resolve_entities=False, no_network=True))
            if suffix == '.docx' and 'word/document.xml' not in z.namelist():
                raise ValueError('missing Word document')
            if suffix == '.xlsx' and 'xl/workbook.xml' not in z.namelist():
                raise ValueError('missing Excel workbook')
        return 'ZIP_CRC_XML_PASS' if suffix != '.zip' else 'ZIP_CRC_PASS'
    if suffix == '.pdf':
        doc = fitz.open(stream=data, filetype='pdf')
        for page in doc:
            page.get_text()
        n = len(doc)
        doc.close()
        return f'PDF_PARSE_PASS:{n}_pages'
    if suffix == '.png':
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
        return 'IMAGE_DECODE_PASS'
    if suffix == '.svg':
        etree.fromstring(data, parser=etree.XMLParser(resolve_entities=False, no_network=True))
        return 'SVG_XML_PASS'
    if suffix == '.gz':
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as g:
            while g.read(1024 * 1024):
                pass
        return 'GZIP_CRC_PASS'
    if suffix in ('.woff', '.ttf'):
        from fontTools.ttLib import TTFont
        font = TTFont(io.BytesIO(data), lazy=False)
        font.getBestCmap()
        font.close()
        return 'FONT_PARSE_PASS'
    if suffix == '.csv':
        list(csv.reader(io.StringIO(data.decode('utf-8-sig'))))
        return 'CSV_DECODE_PASS'
    if suffix in ('.js', '.mjs', '.cjs'):
        data.decode('utf-8')
        return 'JS_TEXT_INVENTORIED;syntax_checked_in_source_check'
    if suffix in ('.html', '.css', '.md', '.txt', '.log') or not suffix:
        data.decode('utf-8-sig')
        return 'TEXT_DECODE_PASS'
    return 'HASH_INVENTORIED'


def main():
    inventory = json.loads((ROOT/'FILE_INVENTORY.json').read_text())
    original = {r['path']: r for r in inventory['files']}
    paths = sorted(p for p in ROOT.rglob('*') if p.is_file())
    rows, errors, memo, secrets = [], [], {}, []
    signature = re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[A-Za-z0-9]{30,}\b')
    for path in paths:
        rel = path.relative_to(ROOT).as_posix()
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        status = memo.get((digest,path.suffix))
        if status is None:
            try:
                status = validate(path, data)
            except Exception as exc:
                status = f'FORMAT_REVIEW:{type(exc).__name__}:{exc}'
                errors.append({'path': rel, 'error': str(exc), 'sha256': digest})
            memo[digest,path.suffix] = status
        if signature.search(data):
            secrets.append(rel)
        expected = original.get(rel)
        match = 'INDEX_FILE' if rel in ('FILE_INVENTORY.json','SHA256SUMS') else 'MATCH' if expected and expected['bytes'] == len(data) and expected['sha256'] == digest else 'MISMATCH'
        rows.append({'path': rel, 'group': group(rel), 'extension': path.suffix or '(none)', 'bytes': len(data), 'sha256': digest, 'manifest': match, 'format_check': status})
    fieldnames = ['path','group','extension','bytes','sha256','manifest','format_check']
    with (OUT/'inventory_6372_files.csv').open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream,fieldnames=fieldnames);writer.writeheader();writer.writerows(rows)
    sums=[]
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        h,rel=line.split('  ',1)
        sums.append({'path':rel,'match':sha(ROOT/rel)==h})
    json_files=[]
    # Every file is classified and hashed; code review/testing is reported separately.
    result={'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'groups':dict(collections.Counter(r['group'] for r in rows)),
            'extensions':dict(collections.Counter(r['extension'] for r in rows)),
            'manifest_matches':dict(collections.Counter(r['manifest'] for r in rows)),
            'sha256sums_entries':len(sums),'sha256sums_failures':[x for x in sums if not x['match']],
            'unique_contents':len({r['sha256'] for r in rows}), 'format_checks':dict(collections.Counter(r['format_check'].split(':')[0] for r in rows)),
            'format_review':errors,'high_confidence_secret_pattern_paths':secrets,
            'boundary':'Format/hash coverage of every file; not a claim of manual review of every question placement or visual verification of every screenshot/document.'}
    (OUT/'whole_archive_integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':main()
