"""Independent bank-wide rational oracle. Does not import application or factory math."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import json, hashlib, time, ast, argparse

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent/'source')
parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
args=parser.parse_args()
OUT=args.out.resolve();OUT.mkdir(parents=True,exist_ok=True)
ROOT=args.root.resolve()
def rational(node):
    kind=node['kind']
    if kind=='rational':
        return Fraction(int(node['numerator']),int(node['denominator']))
    if kind=='binary':
        left,right=rational(node['left']),rational(node['right'])
        op=node['operation']
        if op=='ADD':return left+right
        if op=='SUB':return left-right
        if op=='MUL':return left*right
        if op=='DIV':return left/right
        raise ValueError('Unknown operation '+op)
    raise ValueError('Unknown AST kind '+kind)

def neutral_value(text):
    source=text.translate(str.maketrans({'×':'*','÷':'/','⁄':'/','−':'-','·':'*'}))
    tree=ast.parse(source,mode='eval')
    def walk(n):
        if isinstance(n,ast.Constant) and type(n.value) in (int,float):
            return Fraction(ast.get_source_segment(source,n))
        if isinstance(n,ast.UnaryOp):
            v=walk(n.operand)
            if isinstance(n.op,ast.USub):return -v
            if isinstance(n.op,ast.UAdd):return v
        if isinstance(n,ast.BinOp):
            a,b=walk(n.left),walk(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
        raise ValueError('Unexpected expression node '+type(n).__name__)
    return walk(tree.body)

start=time.time();errors=[];neutral_errors=[];placements=0;steps=0;templates=set();unique={};per_cell={};packages=0;lineage=[]
catalog=json.loads((ROOT/'dist/bank/index.json').read_text())
for grade in catalog['grades']:
    g=json.loads((ROOT/'dist'/grade['url']).read_text())
    for level in g['levels']:
        l=json.loads((ROOT/'dist'/level['url']).read_text())
        for cell in l['competencies']:
            cid=cell['competency_id'];stats={'packages':0,'placements':0,'unique':set(),'template_ids':set()}
            for ref in cell['packages']:
                path=ROOT/'dist'/ref['url'];raw=path.read_bytes();packages+=1;stats['packages']+=1
                if len(raw)!=ref['bytes'] or hashlib.sha256(raw).hexdigest()!=ref['sha256']:errors.append({'kind':'package_integrity','path':ref['url']})
                string=raw.decode();assert string.startswith('export default ')
                pkg=json.loads(string[len('export default '):].strip().removesuffix(';'))
                if pkg['package_id']!=ref['package_id'] or pkg['target_competency_id']!=cid or pkg['question_count']!=len(pkg['questions']) or len(pkg['questions'])!=ref['question_count']:errors.append({'kind':'package_identity','path':ref['url']})
                for qi,q in enumerate(pkg['questions']):
                    placements+=1;stats['placements']+=1;stats['unique'].add(q['fingerprint']);stats['template_ids'].add(q['template_id']);templates.add(q['template_id'])
                    key=(cid,q['fingerprint']);identity=json.dumps(q,sort_keys=True,separators=(',',':'))
                    if key in unique and unique[key]!=hashlib.sha256(identity.encode()).hexdigest():errors.append({'kind':'inconsistent_duplicate','path':ref['url'],'index':qi})
                    unique[key]=hashlib.sha256(identity.encode()).hexdigest()
                    try:
                        value=rational(q['expression_ast']);answer=Fraction(int(q['answer']['numerator']),int(q['answer']['denominator']))
                        if value!=answer:errors.append({'kind':'answer','path':ref['url'],'index':qi,'actual':str(value),'key':str(answer)})
                        for si,step in enumerate(q['solution_steps']):
                            if step.get('expression_ast'):
                                steps+=1
                                sv=rational(step['expression_ast'])
                                if sv!=value:errors.append({'kind':'solution_step','path':ref['url'],'index':qi,'step':si,'actual':str(sv),'expected':str(value)})
                        try:
                            nv=neutral_value(q['neutral_expression'])
                            if nv!=value:neutral_errors.append({'kind':'neutral_mismatch','path':ref['url'],'index':qi,'text':q['neutral_expression'],'actual':str(nv),'expected':str(value)})
                        except Exception as e:neutral_errors.append({'kind':'neutral_parse','path':ref['url'],'index':qi,'text':q['neutral_expression'],'error':str(e)})
                        for section in ['hint','explanation']:
                            if not all(isinstance(q[section].get(lang),str) and q[section][lang].strip() for lang in ['id','en']):errors.append({'kind':'bilingual_blank','path':ref['url'],'index':qi,'field':section})
                    except Exception as e:errors.append({'kind':'oracle_error','path':ref['url'],'index':qi,'error':str(e)})
            per_cell[cid]={**stats,'unique':len(stats['unique']),'template_ids':sorted(stats['template_ids'])}
    print('grade',grade['grade'],'packages',packages,'placements',placements,flush=True)
report={'method':'Independent Python fractions.Fraction AST and neutral-expression evaluator; no app/factory math imports','runtime':'Python','seconds':round(time.time()-start,2),'packages':packages,'placements':placements,'unique_competency_fingerprints':len(unique),'template_families':len(templates),'solution_step_checks':steps,'errors':errors,'neutral_errors':neutral_errors,'active_cells':sum(v['packages']>0 for v in per_cell.values()),'cells':per_cell}
(OUT/'independent_bank_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='cells'},ensure_ascii=False,indent=2))
