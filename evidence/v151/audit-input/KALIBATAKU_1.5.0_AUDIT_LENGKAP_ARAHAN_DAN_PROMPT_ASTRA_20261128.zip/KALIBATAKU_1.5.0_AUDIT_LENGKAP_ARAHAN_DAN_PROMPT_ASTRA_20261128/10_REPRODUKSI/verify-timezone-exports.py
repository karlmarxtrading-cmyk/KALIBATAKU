"""Read the actual exported artifacts without importing the app encoders.

Usage: python verify-timezone-exports.py OUTPUT_DIRECTORY
Requires PyMuPDF for the PDF check. The other readers use Python's stdlib.
This script checks semantics, not rendering in Microsoft Word/Excel.
"""
from pathlib import Path
import csv
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

import fitz

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'reports'
exports = root / 'timezone-offset-exports'
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
results = []

for name, expected_completed, expected_assigned in [('utc', 4, 32), ('offset', 0, 0)]:
    for format in ['json', 'csv', 'xlsx', 'docx', 'pdf']:
        file = exports / f'{name}.{format}'
        result = {'representation': name, 'format': format, 'file': file.name,
                  'sha256': hashlib.sha256(file.read_bytes()).hexdigest()}
        if format == 'json':
            data = json.loads(file.read_text())
            result.update(completed=data['completed'], assigned=data['core']['assigned_count'],
                          correct=data['core']['correct_count'], session_rows=len(data['sessions']))
            assert result['completed'] == expected_completed
            assert result['session_rows'] == expected_completed
            assert result['assigned'] == expected_assigned
        elif format == 'csv':
            rows = list(csv.reader(file.read_text(encoding='utf-8-sig').splitlines()))
            header_at = next(i for i, row in enumerate(rows) if row[:4] == ['Summary', 'Siswa', 'Sumber', 'Soal'])
            header, values = rows[header_at], rows[header_at + 1]
            summary = dict(zip(header, values))
            session_rows = sum(row[:1] == ['Sessions'] for row in rows) - 1
            result.update(assigned=int(summary['Soal']), correct=int(summary['Benar']), session_rows=session_rows)
            assert result['assigned'] == expected_assigned
            assert result['session_rows'] == expected_completed
        elif format == 'xlsx':
            with zipfile.ZipFile(file) as archive:
                sheet = ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
                cells = {cell.attrib['r']: cell.findtext('s:v', namespaces=ns)
                         for cell in sheet.findall('.//s:c', ns)}
            result.update(assigned=int(cells['C2']), correct=int(cells['D2']))
            assert result['assigned'] == expected_assigned
        else:
            if format == 'docx':
                with zipfile.ZipFile(file) as archive:
                    document = ET.fromstring(archive.read('word/document.xml'))
                    text = '\n'.join(''.join(node.itertext()) for node in document.findall('.//w:p', ns))
            else:
                with fitz.open(file) as document:
                    text = '\n'.join(page.get_text() for page in document)
            text = re.sub(r'\s+', ' ', text)
            completed = re.search(r'Sesi selesai dalam periode ini:\s*(\d+)', text)
            missions = re.search(r'Misi dalam periode\s*(\d+)', text)
            assert completed and missions, f'Missing report metrics in {file.name}'
            result.update(completed=int(completed[1]), missions_in_period=int(missions[1]),
                          independent_answers_empty='Belum ada jawaban benar mandiri' in text)
            assert result['completed'] == expected_completed
            assert result['missions_in_period'] == (3 if name == 'utc' else 0)
            assert result['independent_answers_empty'] == (name == 'offset')
        result['check'] = 'PASS: artifact contains the snapshot values'
        results.append(result)

output = {'status': 'REPRODUCED_IN_ALL_FIVE_FORMATS',
          'meaning': 'Semantically equivalent accepted timestamps produce different report contents; this is a reporting defect, not an encoder discrepancy.',
          'readers': {'json_csv_xml': 'Python stdlib', 'pdf': 'PyMuPDF ' + fitz.VersionBind},
          'scope': 'Output semantics only; this is not evidence of physical Word/Excel rendering or assistive-technology behavior.',
          'results': results}
(root / 'timezone-offset-export-verification.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(output, ensure_ascii=False, indent=2))
