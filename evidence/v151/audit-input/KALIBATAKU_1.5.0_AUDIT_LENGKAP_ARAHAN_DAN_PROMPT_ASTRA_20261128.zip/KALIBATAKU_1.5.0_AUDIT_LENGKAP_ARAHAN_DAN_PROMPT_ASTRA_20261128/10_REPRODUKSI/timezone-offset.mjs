import fs from 'node:fs/promises';
import {pathToFileURL,fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
// Usage: node timezone-offset.mjs EXTRACTED_PROJECT OUTPUT_DIRECTORY
const root=path.resolve(process.argv[2]||fileURLToPath(new URL('../../source',import.meta.url)))+'/';
const output=path.resolve(process.argv[3]||fileURLToPath(new URL('../reports',import.meta.url)));
await fs.mkdir(output,{recursive:true});
const load=p=>import(pathToFileURL(root+p));
const {eventHash,canonical,sha256}=await load('dist/data/common.js');
const {readBackup,importBackup}=await load('dist/data/backup.js');
const {listAttempts,scopeForLocal}=await load('dist/data/store.js');
const {buildSnapshot,initialFilters,filterSessions}=await load('dist/teacher/report.js');
const {encode}=await load('dist/teacher/export/index.js');
const fixture=JSON.parse(await fs.readFile(root+'tests/journey/fixtures/report-audit-04-v14.json','utf8'));
const isDate=x=>typeof x==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z$/.test(x);
function convert(x,offset){
 if(isDate(x)){
   const stamp=Date.parse(x)+12*3600000;
   return offset?new Date(stamp+7*3600000).toISOString().replace('Z','+07:00'):new Date(stamp).toISOString();
 }
 if(Array.isArray(x))return x.map(v=>convert(v,offset));
 if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,convert(v,offset)]));
 return x;
}
const utc=convert(fixture.bundles,false),zoned=convert(fixture.bundles,true);
for(const bundles of [utc,zoned])for(const b of bundles)for(const e of b.events)e.payload_hash=await eventHash(e);
const body={format:'kalibataku-profile-backup',schema_version:'1.0.0',release_id:'kalibataku-static-1',data_origin:'local_practice',exported_at:'2026-11-29T00:00:00Z',verification_status:'unverified',profile:{id:fixture.profile_id,name:'Offset ISO fixture'},records:{attempts:zoned.map(b=>({id:b.attempt.attempt_id,data:b.attempt})),events:zoned.flatMap(b=>b.events.map(e=>({id:e.event_id,data:e}))),records:[]}};
const backup={...body,checksum:await sha256(canonical(body,false))};
const utcBody={...body,records:{attempts:utc.map(b=>({id:b.attempt.attempt_id,data:b.attempt})),events:utc.flatMap(b=>b.events.map(e=>({id:e.event_id,data:e}))),records:[]}};
await readBackup({...utcBody,checksum:await sha256(canonical(utcBody,false))});
await readBackup(backup);
const restored=await importBackup(backup);
const attempts=await listAttempts(scopeForLocal(fixture.profile_id));
const person={id:fixture.profile_id,alias:'Offset ISO fixture',classId:'A'};
const filters={...initialFilters(),source:'local_practice',timezone:'Asia/Jakarta',from:'2026-11-28',to:'2026-11-28'};
const input={person,people:[person],filters,locale:'id',createdAt:'2026-11-29T12:00:00Z'};
const utcReport=buildSnapshot({...input,attempts:utc.map(b=>b.attempt)});
const offsetReport=buildSnapshot({...input,attempts});
assert.equal(Date.parse(attempts[0].started_at),Date.parse(utc.at(-1).attempt.started_at));
const boundaryCases=[];
for(const [timezone,instant,label] of [
 ['Asia/Jakarta','2026-11-27T16:59:59.999Z','one millisecond before local day'],
 ['Asia/Jakarta','2026-11-27T17:00:00.000Z','exact start of local day'],
 ['Asia/Jakarta','2026-11-28T16:59:59.999Z','one millisecond before local day end'],
 ['Asia/Jakarta','2026-11-28T17:00:00.000Z','exact exclusive end of local day'],
 ['UTC','2026-11-27T23:59:59.999Z','one millisecond before UTC day'],
 ['UTC','2026-11-28T00:00:00.000Z','exact start of UTC day'],
 ['UTC','2026-11-28T23:59:59.999Z','one millisecond before UTC day end'],
 ['UTC','2026-11-29T00:00:00.000Z','exact exclusive end of UTC day'],
]){
 const offset=new Date(Date.parse(instant)+7*3600000).toISOString().replace('Z','+07:00');
 const get=started_at=>filterSessions([{...utc[0].attempt,started_at}],[person],{...filters,timezone}).length;
 boundaryCases.push({timezone,label,utc:instant,offset,equivalent_instants:Date.parse(instant)===Date.parse(offset),expected:get(instant),actual:get(offset)});
}
const font=[await fs.readFile(root+'dist/teacher/font/DejaVuSans.ttf'),JSON.parse(await fs.readFile(root+'dist/teacher/font/metrics.json','utf8'))];
const formats=[];
const exportDir=path.join(output,'timezone-offset-exports');await fs.mkdir(exportDir,{recursive:true});
for(const [name,snapshot] of [['utc',utcReport],['offset',offsetReport]]){
 for(const format of ['json','csv','xlsx','docx','pdf']){
   const bytes=await encode(snapshot,format,{font});const file=name+'.'+format;
   await fs.writeFile(path.join(exportDir,file),bytes);formats.push({representation:name,format,file,bytes:bytes.length,sha256:await sha256(bytes),input_completed:snapshot.completed,input_assigned:snapshot.counts.N});
 }
}
await fs.writeFile(path.join(output,'timezone-offset-valid-backup.json'),JSON.stringify(backup));
const result={status:offsetReport.completed===4?'PASS':'REPRODUCED',expected_completed:4,actual_completed:offsetReport.completed,utc_representation_completed:utcReport.completed,accepted_backup:true,both_timestamp_representations_pass_backup_validation:true,restored_additions:restored.additions,example_original_utc:utc[0].attempt.started_at,example_equivalent_offset:zoned[0].attempt.started_at,filter:filters,journey_rows:offsetReport.journey.rows.length,activity_sessions:offsetReport.sessions.length,boundary_cases:boundaryCases,exports:formats,runtime:process.version,source_root:root};
await fs.writeFile(path.join(output,'timezone-offset.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
