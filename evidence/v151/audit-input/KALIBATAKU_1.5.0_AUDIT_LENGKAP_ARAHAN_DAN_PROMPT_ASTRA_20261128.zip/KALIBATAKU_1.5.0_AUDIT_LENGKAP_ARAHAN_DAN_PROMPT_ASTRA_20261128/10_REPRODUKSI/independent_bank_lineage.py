"""Compare all current bank bytes with the actual previous release ZIP."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, default=HERE.parent / 'source')
parser.add_argument('--baseline', type=Path, default=HERE.parent / 'baseline_input/KALIBATAKU_ADVENTURE_SOURCE_DIST_BANK_EVIDENCE.zip')
parser.add_argument('--out', type=Path, default=HERE)
args = parser.parse_args()
root, baseline, output = args.root.resolve(), args.baseline.resolve(), args.out.resolve()
output.mkdir(parents=True, exist_ok=True)

digest = hashlib.file_digest(baseline.open('rb'), 'sha256').hexdigest()
expected_baseline_sha256 = '86b030e3196cbf2116ce37bad3a6b7bcb350eadee4d1931cff8ba7bcf094046d'
missing, mismatches = [], []
with zipfile.ZipFile(baseline) as archive:
    entries = [row for row in archive.infolist() if row.filename.startswith('dist/bank/') and not row.is_dir()]
    names = {row.filename for row in entries}
    if len(names) != len(entries):
        raise ValueError('Duplicate bank paths in baseline archive')
    for row in entries:
        path = root / row.filename
        if not path.is_file():
            missing.append(row.filename)
        elif path.read_bytes() != archive.read(row):
            mismatches.append(row.filename)
current = {str(path.relative_to(root)) for path in (root / 'dist/bank').rglob('*') if path.is_file()}
result = {
    'baseline_name': baseline.name,
    'baseline_sha256': digest,
    'expected_baseline_sha256': expected_baseline_sha256,
    'baseline_hash_matches_prior_audit': digest == expected_baseline_sha256,
    'entries': len(entries),
    'missing': missing,
    'mismatches': mismatches,
    'added': sorted(current - names),
}
result['pass'] = bool(entries) and result['baseline_hash_matches_prior_audit'] and not (missing or mismatches or result['added'])
(output / 'independent_bank_lineage_1_4.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['pass'] else 1)
